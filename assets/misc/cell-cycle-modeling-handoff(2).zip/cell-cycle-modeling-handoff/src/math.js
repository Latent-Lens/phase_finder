export const EPS = 1e-12;

export function clamp(value, lower, upper) {
  return Math.min(upper, Math.max(lower, value));
}

export function sum(values) {
  let total = 0;
  for (const value of values) total += value;
  return total;
}

export function mean(values) {
  return values.length ? sum(values) / values.length : NaN;
}

export function variance(values, sample = false) {
  if (values.length < (sample ? 2 : 1)) return NaN;
  const m = mean(values);
  let ss = 0;
  for (const value of values) ss += (value - m) ** 2;
  return ss / (values.length - (sample ? 1 : 0));
}

export function softplus(x) {
  if (x > 30) return x;
  if (x < -30) return Math.exp(x);
  return Math.log1p(Math.exp(x));
}

export function sigmoid(x) {
  if (x >= 0) {
    const z = Math.exp(-x);
    return 1 / (1 + z);
  }
  const z = Math.exp(x);
  return z / (1 + z);
}

// Abramowitz-Stegun approximation; adequate for histogram bin integration.
export function erf(x) {
  const sign = x < 0 ? -1 : 1;
  const ax = Math.abs(x);
  const t = 1 / (1 + 0.3275911 * ax);
  const a1 = 0.254829592;
  const a2 = -0.284496736;
  const a3 = 1.421413741;
  const a4 = -1.453152027;
  const a5 = 1.061405429;
  const y = 1 - (((((a5 * t + a4) * t + a3) * t + a2) * t + a1) * t) * Math.exp(-ax * ax);
  return sign * y;
}

export function normalPdf(x, mu = 0, sigma = 1) {
  const s = Math.max(Math.abs(sigma), EPS);
  const z = (x - mu) / s;
  return Math.exp(-0.5 * z * z) / (Math.sqrt(2 * Math.PI) * s);
}

export function normalCdf(x, mu = 0, sigma = 1) {
  const s = Math.max(Math.abs(sigma), EPS);
  return 0.5 * (1 + erf((x - mu) / (s * Math.SQRT2)));
}

export function normalSurvival(x, mu = 0, sigma = 1) {
  return 1 - normalCdf(x, mu, sigma);
}

export function binCenters(edges) {
  const centers = new Array(edges.length - 1);
  for (let i = 0; i < centers.length; i += 1) centers[i] = 0.5 * (edges[i] + edges[i + 1]);
  return centers;
}

export function isUniformGrid(edges, tolerance = 1e-8) {
  if (edges.length < 3) return true;
  const width = edges[1] - edges[0];
  for (let i = 1; i < edges.length - 1; i += 1) {
    if (Math.abs((edges[i + 1] - edges[i]) - width) > tolerance * Math.max(1, Math.abs(width))) return false;
  }
  return true;
}

export function gaussianBinMass(edges, area, mu, sigma) {
  const out = new Array(edges.length - 1);
  const a = Math.max(0, area);
  const s = Math.max(Math.abs(sigma), EPS);
  for (let i = 0; i < out.length; i += 1) {
    out[i] = a * Math.max(0, normalCdf(edges[i + 1], mu, s) - normalCdf(edges[i], mu, s));
  }
  return out;
}

export function normalizePositive(values, target = 1) {
  const clipped = values.map((value) => Math.max(0, Number.isFinite(value) ? value : 0));
  const total = sum(clipped);
  if (total <= EPS) {
    const equal = target / Math.max(1, clipped.length);
    return clipped.map(() => equal);
  }
  const scale = target / total;
  return clipped.map((value) => value * scale);
}

export function addArrays(...arrays) {
  if (!arrays.length) return [];
  const length = arrays[0].length;
  const out = new Array(length).fill(0);
  for (const array of arrays) {
    if (array.length !== length) throw new Error('Array lengths must match.');
    for (let i = 0; i < length; i += 1) out[i] += array[i];
  }
  return out;
}

export function scaleArray(values, factor) {
  return values.map((value) => value * factor);
}

export function poissonLogLikelihood(observed, expected) {
  if (observed.length !== expected.length) throw new Error('Observed and expected lengths must match.');
  let ll = 0;
  for (let i = 0; i < observed.length; i += 1) {
    const y = Math.max(0, observed[i]);
    const mu = Math.max(EPS, expected[i]);
    // The log(y!) constant is omitted because it cancels in model comparisons.
    ll += y * Math.log(mu) - mu;
  }
  return ll;
}

export function poissonNll(observed, expected) {
  return -poissonLogLikelihood(observed, expected);
}

export function poissonDeviance(observed, expected) {
  let deviance = 0;
  for (let i = 0; i < observed.length; i += 1) {
    const y = Math.max(0, observed[i]);
    const mu = Math.max(EPS, expected[i]);
    deviance += y === 0 ? 2 * mu : 2 * (y * Math.log(y / mu) - (y - mu));
  }
  return deviance;
}

export function quantile(values, q) {
  if (!values.length) return NaN;
  const sorted = [...values].sort((a, b) => a - b);
  const p = clamp(q, 0, 1) * (sorted.length - 1);
  const lo = Math.floor(p);
  const hi = Math.ceil(p);
  if (lo === hi) return sorted[lo];
  const w = p - lo;
  return sorted[lo] * (1 - w) + sorted[hi] * w;
}

export function choose(n, k) {
  if (!Number.isInteger(n) || !Number.isInteger(k) || k < 0 || n < 0 || k > n) return 0;
  const kk = Math.min(k, n - k);
  let result = 1;
  for (let i = 1; i <= kk; i += 1) result = (result * (n - kk + i)) / i;
  return result;
}

export function finiteDifferenceGradient(fn, x, relativeStep = 1e-5) {
  const gradient = new Array(x.length);
  const fx = fn(x);
  for (let i = 0; i < x.length; i += 1) {
    const h = relativeStep * Math.max(1, Math.abs(x[i]));
    const xp = [...x];
    xp[i] += h;
    gradient[i] = (fn(xp) - fx) / h;
  }
  return gradient;
}

export function interpolateBinValue(edges, values, x) {
  if (values.length !== edges.length - 1) throw new Error('Values must have one entry per bin.');
  if (x < edges[0] || x >= edges.at(-1)) return 0;
  let lo = 0;
  let hi = values.length - 1;
  while (lo <= hi) {
    const mid = (lo + hi) >> 1;
    if (x < edges[mid]) hi = mid - 1;
    else if (x >= edges[mid + 1]) lo = mid + 1;
    else return values[mid];
  }
  return 0;
}
