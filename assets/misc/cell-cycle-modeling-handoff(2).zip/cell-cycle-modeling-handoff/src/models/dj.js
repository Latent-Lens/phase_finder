import { addArrays } from '../math.js';
import { convolvedSPhase, peakComponents, polynomialProfile } from './shared.js';

/**
 * Dean-Jett model:
 *   total = Gaussian(G1) + broadened quadratic S phase + Gaussian(G2/M)
 *
 * The stable option applies softplus to the latent polynomial to prevent
 * negative expected cell counts. Set stable=false for a closer literal form.
 */
export function djExpectedCounts(edges, params, options = {}) {
  const stable = options.stable ?? true;
  const peaks = peakComponents(edges, params);
  const s = convolvedSPhase(edges, {
    area: params.sArea,
    g1Mean: peaks.g1Mean,
    g2Mean: peaks.g2Mean,
    broadeningCV: params.sBroadeningCV ?? params.g1CV,
    latentProfile: (z) => polynomialProfile(z, params.s0, params.s1, params.s2, stable),
  });

  return {
    model: 'Dean-Jett',
    edges,
    total: addArrays(peaks.g1, s, peaks.g2),
    components: { g1: peaks.g1, s, g2: peaks.g2 },
    derived: {
      g1Mean: peaks.g1Mean,
      g2Mean: peaks.g2Mean,
      g1Sd: peaks.g1Sd,
      g2Sd: peaks.g2Sd,
      ratio: peaks.g2Mean / peaks.g1Mean,
    },
  };
}
