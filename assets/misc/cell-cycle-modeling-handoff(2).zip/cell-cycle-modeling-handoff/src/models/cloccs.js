import {
  EPS,
  addArrays,
  choose,
  gaussianBinMass,
  normalCdf,
  normalPdf,
  normalSurvival,
  normalizePositive,
  poissonNll,
  sum,
} from '../math.js';

/**
 * Orlando et al. CLOCCS cohort parameters.
 * theta = { mu0, sigma0, sigmaV, lambda, delta, maxCycles }
 *
 * Cohort {g,r} position at time t:
 *   P_t = P_0 + V t - g*delta - r*lambda
 * with mean -mu0 + t - g*delta - r*lambda and
 * SD sqrt(sigma0^2 + t^2 sigmaV^2).
 */
export function cohortPositionDistribution(t, g, r, theta) {
  const sd = Math.sqrt(theta.sigma0 ** 2 + (t * theta.sigmaV) ** 2);
  return {
    mean: -theta.mu0 + t - g * theta.delta - r * theta.lambda,
    sd: Math.max(EPS, sd),
    lower: g === 0 && r === 0 ? -Infinity : -theta.delta,
  };
}

/**
 * Unnormalized cohort mass. For descendants, the binomial term counts lineage
 * paths contributing to cohort {g,r}; the survival term is the chance the
 * founder lineage has crossed the cohort's birth threshold.
 */
export function cohortMass(t, g, r, theta) {
  if (g === 0 && r === 0) return 1;
  if (g < 1 || r < g) return 0;
  const founderMean = -theta.mu0 + t;
  const founderSd = Math.sqrt(theta.sigma0 ** 2 + (t * theta.sigmaV) ** 2);
  const threshold = r * theta.lambda + (g - 1) * theta.delta;
  return choose(r - 1, g - 1) * normalSurvival(threshold, founderMean, founderSd);
}

export function enumerateCohorts(t, theta) {
  const maxCycles = Math.max(1, Math.floor(theta.maxCycles ?? 5));
  const cohorts = [{ g: 0, r: 0, mass: 1 }];
  for (let r = 1; r <= maxCycles; r += 1) {
    for (let g = 1; g <= r; g += 1) {
      const mass = cohortMass(t, g, r, theta);
      if (mass > 1e-10) cohorts.push({ g, r, mass });
    }
  }
  const total = sum(cohorts.map((cohort) => cohort.mass));
  return cohorts.map((cohort) => ({ ...cohort, weight: cohort.mass / total }));
}

export function expectedDnaSignal(position, theta, psi) {
  // Recovery and daughter-specific delay are G1-like in DNA content.
  if (position < 0) return psi.alpha1;
  const cyclePosition = ((position % theta.lambda) + theta.lambda) % theta.lambda;
  const fraction = cyclePosition / theta.lambda;

  if (fraction < psi.gamma1) return psi.alpha1;
  if (fraction < psi.gamma2) {
    const sFraction = (fraction - psi.gamma1) / Math.max(EPS, psi.gamma2 - psi.gamma1);
    return psi.alpha1 + psi.alpha2 * sFraction;
  }
  return psi.alpha1 + psi.alpha2;
}

function truncatedNormalQuadrature(distribution, points = 96) {
  const lower = distribution.lower;
  const lo = Number.isFinite(lower) ? lower : distribution.mean - 5 * distribution.sd;
  const hi = Math.max(lo + EPS, distribution.mean + 5 * distribution.sd);
  const dx = (hi - lo) / points;
  const normalizer = Number.isFinite(lower)
    ? Math.max(EPS, 1 - normalCdf(lower, distribution.mean, distribution.sd))
    : 1;
  const out = [];
  for (let i = 0; i < points; i += 1) {
    const x = lo + (i + 0.5) * dx;
    const density = normalPdf(x, distribution.mean, distribution.sd) / normalizer;
    out.push({ x, weight: density * dx });
  }
  return out;
}

/**
 * Numerical forward model for the CLOCCS DNA-content sampling distribution.
 * psi = { alpha1, alpha2, tau, gamma1, gamma2, totalEvents }
 */
export function cloccsExpectedHistogramAtTime(edges, t, theta, psi, options = {}) {
  const cohorts = enumerateCohorts(t, theta);
  const probabilities = new Array(edges.length - 1).fill(0);
  const quadraturePoints = options.quadraturePoints ?? 96;

  for (const cohort of cohorts) {
    const distribution = cohortPositionDistribution(t, cohort.g, cohort.r, theta);
    const quadrature = truncatedNormalQuadrature(distribution, quadraturePoints);
    for (const point of quadrature) {
      const signal = expectedDnaSignal(point.x, theta, psi);
      const measurement = gaussianBinMass(edges, cohort.weight * point.weight, signal, psi.tau);
      for (let i = 0; i < probabilities.length; i += 1) probabilities[i] += measurement[i];
    }
  }

  const totalEvents = psi.totalEvents ?? 1;
  const counts = normalizePositive(probabilities, totalEvents);
  return {
    model: 'CLOCCS DNA sampling model',
    edges,
    total: counts,
    components: {},
    cohorts,
    t,
  };
}

export function cloccsTimeSeriesNll(series, theta, psiByTime, options = {}) {
  let loss = 0;
  for (let i = 0; i < series.length; i += 1) {
    const sample = series[i];
    const psi = Array.isArray(psiByTime) ? psiByTime[i] : psiByTime(sample.t, i);
    const prediction = cloccsExpectedHistogramAtTime(sample.edges, sample.t, theta, {
      ...psi,
      totalEvents: sum(sample.counts),
    }, options);
    loss += poissonNll(sample.counts, prediction.total);
  }
  return loss;
}

/**
 * Optional budding-index probability from lifeline position. This numerical
 * version integrates each cohort over the budded interval gamma >= beta.
 */
export function cloccsBuddedProbability(t, theta, beta, options = {}) {
  const cohorts = enumerateCohorts(t, theta);
  let probability = 0;
  const quadraturePoints = options.quadraturePoints ?? 128;
  for (const cohort of cohorts) {
    const distribution = cohortPositionDistribution(t, cohort.g, cohort.r, theta);
    for (const point of truncatedNormalQuadrature(distribution, quadraturePoints)) {
      if (point.x < 0) continue;
      const cyclePosition = ((point.x % theta.lambda) + theta.lambda) % theta.lambda;
      const fraction = cyclePosition / theta.lambda;
      if (fraction >= beta) probability += cohort.weight * point.weight;
    }
  }
  return Math.min(1, Math.max(0, probability));
}

export const CLOCCS_IMPLEMENTATION_NOTE = [
  'This module implements the published cohort/lifeline structure and a numerical DNA sampling model.',
  'It is not a reproduction of the paper\'s full Bayesian inference code or priors.',
  'Use CLOCCS only for synchronized time series; it is not a replacement for a single-histogram DJ/DJF fit.',
];
