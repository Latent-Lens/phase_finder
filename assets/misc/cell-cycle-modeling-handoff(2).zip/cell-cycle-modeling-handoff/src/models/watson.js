import { addArrays, binCenters, gaussianBinMass, sum } from '../math.js';
import { estimatePeakSigma, gaussianSmooth } from '../histogram.js';
import { boundedNelderMead } from '../optimizer.js';
import {
  estimatePeakFromRegion,
  peakRegionBoundaryWarnings,
  summarizePeakRegionMigration,
  validatePeakRegions,
} from '../peakRegions.js';

function fitLocalGaussian(edges, counts, initial, bounds, fitMask) {
  const objective = ([area, mean, sd]) => {
    const expected = gaussianBinMass(edges, area, mean, sd);
    let loss = 0;
    for (let i = 0; i < counts.length; i += 1) {
      if (!fitMask(i)) continue;
      const residual = counts[i] - expected[i];
      loss += residual * residual / Math.max(1, counts[i]);
    }
    return loss;
  };

  const result = boundedNelderMead({
    objective,
    initial: [initial.area, initial.mean, initial.sd],
    lower: [bounds.area[0], bounds.mean[0], bounds.sd[0]],
    upper: [bounds.area[1], bounds.mean[1], bounds.sd[1]],
    maxIterations: 600,
  });
  return { area: result.x[0], mean: result.x[1], sd: result.x[2], optimization: result };
}

/**
 * Watson Pragmatic implementation blueprint.
 *
 * The model fits G1 and G2/M Gaussians locally, then treats the nonnegative
 * residual between the fitted peaks as S phase. It is deliberately pragmatic,
 * not a fully generative S-phase model, and should not be compared to DJ/DJF by
 * AIC/BIC as though it had the same likelihood structure.
 */
export function fitWatsonPragmatic({ edges, counts, anchors = {}, peakRegions = null, smoothSigma = 1.5 }) {
  const centers = binCenters(edges);
  const smoothed = gaussianSmooth(counts, smoothSigma);
  const n = counts.length;
  const total = sum(counts);

  const selectedRegions = peakRegions ? validatePeakRegions(peakRegions) : null;
  const binWidth = edges[1] - edges[0];
  let g1Index;
  let g1RegionEstimate = null;

  if (selectedRegions) {
    g1RegionEstimate = estimatePeakFromRegion(edges, counts, selectedRegions.g1, {
      smoothed,
      label: 'G1',
      cleanSide: 'left',
    });
    g1Index = g1RegionEstimate.peakIndex;
  } else {
    const searchEnd = anchors.g1SearchEndIndex ?? Math.floor(n * 0.6);
    g1Index = anchors.g1Index;
    if (!Number.isInteger(g1Index)) {
      g1Index = 0;
      for (let i = 1; i <= searchEnd; i += 1) if (smoothed[i] > smoothed[g1Index]) g1Index = i;
    }
  }

  // Watson's published description uses the width near 60% of peak height.
  const g1SigmaBins = estimatePeakSigma(smoothed, g1Index, 0.60);
  const g1InitialSd = selectedRegions
    ? Math.max(binWidth, g1RegionEstimate.sigma)
    : Math.max(binWidth, g1SigmaBins * binWidth);
  const g1InitialMean = anchors.g1Mean ?? g1RegionEstimate?.mean ?? centers[g1Index];
  const g1InitialArea = anchors.g1Area ?? g1RegionEstimate?.area ??
    Math.min(total, smoothed[g1Index] * g1InitialSd * Math.sqrt(2 * Math.PI) / binWidth);

  const g1 = fitLocalGaussian(
    edges,
    counts,
    { area: g1InitialArea, mean: g1InitialMean, sd: g1InitialSd },
    {
      area: [0, total * 1.2],
      mean: selectedRegions
        ? [selectedRegions.g1.left, selectedRegions.g1.right]
        : anchors.g1MeanBounds ?? [g1InitialMean - 1.5 * g1InitialSd, g1InitialMean + 1.5 * g1InitialSd],
      sd: [0.25 * g1InitialSd, 3 * g1InitialSd],
    },
    selectedRegions
      ? (i) => centers[i] >= selectedRegions.g1.left && centers[i] <= selectedRegions.g1.right
      : (i) => centers[i] >= g1InitialMean - 3 * g1InitialSd && centers[i] <= g1InitialMean + 1 * g1InitialSd,
  );

  const ratioGuess = anchors.ratio ?? 1.75;
  let g2RegionEstimate = null;
  let g2InitialMean;
  let g2Index;
  if (selectedRegions) {
    g2RegionEstimate = estimatePeakFromRegion(edges, counts, selectedRegions.g2, {
      smoothed,
      label: 'G2/M',
      cleanSide: 'right',
    });
    g2InitialMean = anchors.g2Mean ?? g2RegionEstimate.mean;
    g2Index = g2RegionEstimate.peakIndex;
  } else {
    g2InitialMean = anchors.g2Mean ?? ratioGuess * g1.mean;
    g2Index = centers.reduce((best, value, i) => Math.abs(value - g2InitialMean) < Math.abs(centers[best] - g2InitialMean) ? i : best, 0);
  }
  const g2SigmaBins = estimatePeakSigma(smoothed, g2Index, 0.60);
  const g2InitialSd = selectedRegions
    ? Math.max(g1.sd, g2RegionEstimate.sigma)
    : Math.max(g1.sd, g2SigmaBins * binWidth);
  const g2InitialArea = anchors.g2Area ?? g2RegionEstimate?.area ??
    Math.min(total, smoothed[g2Index] * g2InitialSd * Math.sqrt(2 * Math.PI) / binWidth);

  const g2 = fitLocalGaussian(
    edges,
    counts,
    { area: g2InitialArea, mean: g2InitialMean, sd: g2InitialSd },
    {
      area: [0, total * 1.2],
      mean: selectedRegions
        ? [selectedRegions.g2.left, selectedRegions.g2.right]
        : anchors.g2MeanBounds ?? [1.55 * g1.mean, 2.25 * g1.mean],
      sd: [0.25 * g2InitialSd, 3 * g2InitialSd],
    },
    selectedRegions
      ? (i) => centers[i] >= selectedRegions.g2.left && centers[i] <= selectedRegions.g2.right
      : (i) => centers[i] >= g2InitialMean - 1.5 * g2InitialSd && centers[i] <= g2InitialMean + 3 * g2InitialSd,
  );

  const g1Counts = gaussianBinMass(edges, g1.area, g1.mean, g1.sd);
  const g2Counts = gaussianBinMass(edges, g2.area, g2.mean, g2.sd);
  const s = counts.map((value, i) => {
    if (centers[i] <= g1.mean || centers[i] >= g2.mean) return 0;
    return Math.max(0, value - g1Counts[i] - g2Counts[i]);
  });

  return {
    model: 'Watson Pragmatic',
    edges,
    total: addArrays(g1Counts, s, g2Counts),
    components: { g1: g1Counts, s, g2: g2Counts },
    params: {
      g1Area: g1.area,
      g1Mean: g1.mean,
      g1Sd: g1.sd,
      g2Area: g2.area,
      g2Mean: g2.mean,
      g2Sd: g2.sd,
      ratio: g2.mean / g1.mean,
    },
    notes: [
      'S phase is the nonnegative residual between locally fitted G1 and G2/M peaks.',
      'This is a pragmatic decomposition rather than a fully generative S-phase density.',
    ],
    warnings: selectedRegions ? peakRegionBoundaryWarnings({
      g1Mean: g1.mean,
      g2Mean: g2.mean,
    }, selectedRegions) : [],
    peakRegionMigration: selectedRegions ? summarizePeakRegionMigration(
      { g1Mean: g1InitialMean, g2Mean: g2InitialMean },
      { g1Mean: g1.mean, g2Mean: g2.mean },
      selectedRegions,
    ) : undefined,
    provenance: selectedRegions ? {
      peakRegions: structuredClone(selectedRegions),
      peakRegionHandlesMovedDuringFit: false,
    } : {},
  };
}
