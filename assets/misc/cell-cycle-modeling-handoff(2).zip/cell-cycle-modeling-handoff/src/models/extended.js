import { addArrays } from '../math.js';
import {
  aggregateDoubletComponent,
  debrisComponent,
  subG1Component,
} from '../components.js';
import { djExpectedCounts } from './dj.js';

/**
 * Add optional contaminant components to a DJ/DJF biological model and return
 * one joint expected-count vector suitable for optimization.
 *
 * Parameters are enabled by options rather than inferred merely because a
 * numeric parameter happens to exist. This keeps model dimension explicit for
 * AIC/BIC and prevents invisible overfitting.
 */
export function extendedCellCycleExpectedCounts(edges, params, options = {}) {
  const baseModel = options.baseModel ?? djExpectedCounts;
  const enabled = options.enabled ?? {};
  const base = baseModel(edges, params, options.baseModelOptions ?? {});
  const components = { ...base.components };
  const extras = [];

  if (enabled.debris) {
    components.debris = debrisComponent(edges, {
      area: params.debrisArea,
      rate: params.debrisRate,
      min: options.debrisMin ?? edges[0],
      cutoff: params.debrisCutoff ?? options.debrisCutoff ?? base.derived.g1Mean,
    });
    extras.push(components.debris);
  }

  if (enabled.subG1) {
    components.subG1 = subG1Component(edges, {
      area: params.subG1Area,
      mean: params.subG1Mean,
      sd: params.subG1Sd,
      upperCutoff: params.subG1Cutoff ?? options.subG1Cutoff ?? base.derived.g1Mean,
    });
    extras.push(components.subG1);
  }

  if (enabled.aggregate) {
    const singletBiology = addArrays(base.components.g1, base.components.s, base.components.g2);
    components.aggregate = aggregateDoubletComponent(edges, singletBiology, params.aggregateArea);
    extras.push(components.aggregate);
  }

  return {
    ...base,
    model: `${base.model} + optional components`,
    components,
    total: addArrays(base.total, ...extras),
    enabledComponents: { ...enabled },
  };
}
