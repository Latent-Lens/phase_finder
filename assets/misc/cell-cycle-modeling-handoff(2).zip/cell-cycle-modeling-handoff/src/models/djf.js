import { addArrays, normalPdf } from '../math.js';
import { convolvedSPhase, peakComponents, polynomialProfile } from './shared.js';

/**
 * Dean-Jett-Fox model:
 *   total = Gaussian(G1) + broadened [quadratic + floating Gaussian] S phase
 *           + Gaussian(G2/M)
 *
 * waveMean and waveSD are expressed on normalized S-phase position z in [0,1].
 * waveAmplitude is relative to the quadratic's latent scale; the full latent
 * profile is normalized to sArea before instrumental/biological broadening.
 */
export function djfExpectedCounts(edges, params, options = {}) {
  const stable = options.stable ?? true;
  const peaks = peakComponents(edges, params);
  const s = convolvedSPhase(edges, {
    area: params.sArea,
    g1Mean: peaks.g1Mean,
    g2Mean: peaks.g2Mean,
    broadeningCV: params.sBroadeningCV ?? params.g1CV,
    latentProfile: (z) => {
      const polynomial = polynomialProfile(z, params.s0, params.s1, params.s2, stable);
      const wave = Math.max(0, params.waveAmplitude) * normalPdf(z, params.waveMean, params.waveSD);
      return polynomial + wave;
    },
  });

  return {
    model: 'Dean-Jett-Fox',
    edges,
    total: addArrays(peaks.g1, s, peaks.g2),
    components: { g1: peaks.g1, s, g2: peaks.g2 },
    derived: {
      g1Mean: peaks.g1Mean,
      g2Mean: peaks.g2Mean,
      g1Sd: peaks.g1Sd,
      g2Sd: peaks.g2Sd,
      ratio: peaks.g2Mean / peaks.g1Mean,
      waveMeanDna: peaks.g1Mean + params.waveMean * (peaks.g2Mean - peaks.g1Mean),
    },
  };
}
