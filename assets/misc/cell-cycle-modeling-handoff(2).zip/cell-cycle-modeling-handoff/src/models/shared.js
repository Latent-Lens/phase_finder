import {
  EPS,
  binCenters,
  gaussianBinMass,
  normalCdf,
  normalizePositive,
  softplus,
} from '../math.js';

export function polynomialProfile(z, p0, p1, p2, stable = true) {
  const value = p0 + p1 * z + p2 * z * z;
  return stable ? softplus(value) : value;
}

/**
 * Discrete Dean-Jett-style S-phase broadening.
 * Each latent S-phase DNA position contributes a Gaussian with constant CV.
 */
export function convolvedSPhase(edges, {
  area,
  g1Mean,
  g2Mean,
  broadeningCV,
  latentProfile,
}) {
  const centers = binCenters(edges);
  const latentIndexes = [];
  const rawWeights = [];

  for (let j = 0; j < centers.length; j += 1) {
    const xj = centers[j];
    if (xj < g1Mean || xj > g2Mean) continue;
    const z = (xj - g1Mean) / Math.max(EPS, g2Mean - g1Mean);
    latentIndexes.push(j);
    rawWeights.push(Math.max(0, latentProfile(z, xj)));
  }

  const latentMasses = normalizePositive(rawWeights, Math.max(0, area));
  const out = new Array(centers.length).fill(0);

  for (let latent = 0; latent < latentIndexes.length; latent += 1) {
    const xj = centers[latentIndexes[latent]];
    const sigma = Math.max(EPS, Math.abs(broadeningCV * xj));
    const mass = latentMasses[latent];
    for (let i = 0; i < out.length; i += 1) {
      out[i] += mass * Math.max(0, normalCdf(edges[i + 1], xj, sigma) - normalCdf(edges[i], xj, sigma));
    }
  }
  return out;
}

export function peakComponents(edges, params) {
  const g1Mean = params.g1Mean;
  const g2Mean = params.g2Mean ?? params.ratio * params.g1Mean;
  const g1Sd = params.g1Sd ?? params.g1CV * g1Mean;
  const g2Sd = params.g2Sd ?? params.g2CV * g2Mean;
  return {
    g1Mean,
    g2Mean,
    g1Sd,
    g2Sd,
    g1: gaussianBinMass(edges, params.g1Area, g1Mean, g1Sd),
    g2: gaussianBinMass(edges, params.g2Area, g2Mean, g2Sd),
  };
}
