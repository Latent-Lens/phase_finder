import { sum } from './math.js';
import { initializeCellCycle, applyUserAnchors } from './initialization.js';
import {
  applyPeakRegionsToInitialization,
  buildPeakMeanParameterization,
  summarizePeakRegionMigration,
} from './peakRegions.js';
import { fitHistogramModel } from './optimizer.js';
import { djExpectedCounts } from './models/dj.js';
import { djfExpectedCounts } from './models/djf.js';
import { diagnoseFit } from './diagnostics.js';
import { selectSimpleVsComplex } from './modelSelection.js';

function commonBounds(edges, counts, initial, userConstraints = {}, meanConfiguration = null) {
  const total = sum(counts);
  const minX = edges[0];
  const maxX = edges.at(-1);
  const g1MeanRange = userConstraints.g1MeanRange ?? [
    Math.max(minX, initial.g1Mean * 0.75),
    Math.min(maxX, initial.g1Mean * 1.25),
  ];
  const ratioRange = userConstraints.ratioRange ?? [1.80, 2.15];

  const bounds = {
    g1Area: [1e-3, total * 1.25],
    g1Mean: g1MeanRange,
    g1CV: userConstraints.g1CVRange ?? [0.005, 0.35],
    g2Area: [1e-3, total * 1.25],
    ratio: ratioRange,
    g2CV: userConstraints.g2CVRange ?? [0.005, 0.35],
    sArea: [1e-3, total * 1.25],
    s0: [-8, 8],
    s1: [-12, 12],
    s2: [-12, 12],
    waveAmplitude: [0, 20],
    waveMean: [0.02, 0.98],
    waveSD: [0.015, 0.45],
  };

  if (meanConfiguration) Object.assign(bounds, meanConfiguration.meanBounds);
  return bounds;
}

function attachDiagnostics(fit, counts, metadata) {
  return {
    ...fit,
    diagnostics: diagnoseFit({
      observed: counts,
      expected: fit.expected,
      params: fit.params,
      bounds: fit.bounds,
      parameterCount: fit.parameterCount,
      metadata,
    }),
  };
}

function attachPeakRegionProvenance(fit, initial, peakRegions) {
  if (!peakRegions) return fit;
  return {
    ...fit,
    peakRegionMigration: summarizePeakRegionMigration(initial, fit.params, peakRegions),
    provenance: {
      ...(fit.provenance ?? {}),
      peakRegions: structuredClone(peakRegions),
      peakRegionHandlesMovedDuringFit: false,
    },
  };
}


function summarizePairForProvenance(pair) {
  if (!pair) return null;
  return {
    g1: { index: pair.g1.index, x: pair.g1.x, id: pair.g1.id },
    g2: { index: pair.g2.index, x: pair.g2.x, id: pair.g2.id },
    ratio: pair.ratio,
    score: pair.score,
    components: { ...pair.components },
  };
}

function attachInitializationProvenance(fit, initialization, peakRegionsSource) {
  const detection = initialization.detection;
  return {
    ...fit,
    provenance: {
      ...(fit.provenance ?? {}),
      peakRegionsSource,
      automaticPeakDetection: detection ? {
        status: detection.status,
        confidence: detection.confidence,
        reasons: [...(detection.reasons ?? [])],
        selectedPair: summarizePairForProvenance(detection.selectedPair),
        alternatives: (detection.alternatives ?? []).map(summarizePairForProvenance),
        smoothingScales: [...(initialization.smoothingScales ?? [])],
        configuration: structuredClone(initialization.peakDetectionConfiguration ?? {}),
      } : undefined,
    },
  };
}

/**
 * Recommended UI-facing sequence:
 * 1) initialize from histogram,
 * 2) optionally replace peak identity with immutable left/right G1 and G2/M
 *    regions,
 * 3) fit peak centers only inside their assigned regions,
 * 4) fit DJ and DJF and conservatively select simple vs complex S phase,
 * 5) expose components/residuals for user review.
 */
export function fitAutoCellCycle({
  edges,
  counts,
  userAnchors = {},
  peakRegions = userAnchors.peakRegions,
  constraints = {},
  metadata = {},
  optimizerOptions = {},
  initializationOptions = {},
}) {
  let initialization = initializeCellCycle(edges, counts, initializationOptions);
  initialization = applyUserAnchors(initialization, userAnchors);

  const effectivePeakRegions = peakRegions ?? (constraints.useAutomaticPeakRegions ?? true
    ? initialization.autoPeakRegions
    : null);
  const peakRegionsSource = peakRegions ? 'user' : (effectivePeakRegions ? 'automatic' : 'none');

  let meanConfiguration = null;
  if (effectivePeakRegions) {
    initialization = applyPeakRegionsToInitialization(
      initialization,
      edges,
      counts,
      effectivePeakRegions,
      {
        reinitializeWidths: constraints.reinitializeWidthsFromPeakRegions ?? true,
        reinitializeAreas: constraints.reinitializeAreasFromPeakRegions ?? false,
      },
    );
    meanConfiguration = buildPeakMeanParameterization({
      initial: initialization.params,
      peakRegions: effectivePeakRegions,
      ratioMode: constraints.ratioMode ?? 'bounded',
      ratioRange: constraints.ratioRange ?? [1.80, 2.15],
      lockedRatio: constraints.lockedRatio ?? 2,
    });
  }

  const initial = meanConfiguration?.initial ?? initialization.params;
  const bounds = commonBounds(edges, counts, initial, constraints, meanConfiguration);
  const equalPeakCVs = constraints.equalPeakCVs ?? true;
  const meanKeys = meanConfiguration?.meanKeys ?? ['g1Mean', 'ratio'];
  const meanTransform = meanConfiguration?.parameterTransform ?? ((params) => params);
  const meanPenalty = meanConfiguration?.objectivePenalty ?? (() => 0);

  const simpleKeys = [
    'g1Area', ...meanKeys, 'g1CV', 'g2Area',
    ...(equalPeakCVs ? [] : ['g2CV']),
    'sArea', 's0', 's1', 's2',
  ];
  const complexKeys = [...simpleKeys, 'waveAmplitude', 'waveMean', 'waveSD'];

  const applyLinkedParameters = (rawParams) => {
    const withMeans = meanTransform(rawParams);
    return equalPeakCVs ? { ...withMeans, g2CV: withMeans.g1CV } : withMeans;
  };
  const simpleModel = (modelEdges, params) => djExpectedCounts(modelEdges, params);
  const complexModel = (modelEdges, params) => djfExpectedCounts(modelEdges, params);
  const diagnosticMetadata = {
    ...metadata,
    onlyOnePeak: initialization.detection?.status === 'inferred_g2',
    peakDetectionStatus: initialization.detection?.status,
    peakDetectionConfidence: initialization.detection?.confidence,
    peakRegions: meanConfiguration?.peakRegions,
    peakRegionsSource,
  };

  let simple = attachDiagnostics(fitHistogramModel({
    edges,
    counts,
    model: simpleModel,
    initial,
    bounds,
    keys: simpleKeys,
    optimizerOptions,
    parameterTransform: applyLinkedParameters,
    objectivePenalty: meanPenalty,
  }), counts, diagnosticMetadata);
  simple = attachPeakRegionProvenance(simple, initial, meanConfiguration?.peakRegions);
  simple = attachInitializationProvenance(simple, initialization, peakRegionsSource);

  // Preserve the original peak-location initialization for the complex fit.
  // The simple optimum may absorb a real interior S-phase wave by shifting or
  // broadening a peak. Areas and CVs can still inherit the simple solution.
  const complexInitial = {
    ...initial,
    g1Area: simple.params.g1Area,
    g1CV: simple.params.g1CV,
    g2CV: equalPeakCVs ? simple.params.g1CV : initial.g2CV,
  };
  let complex = attachDiagnostics(fitHistogramModel({
    edges,
    counts,
    model: complexModel,
    initial: complexInitial,
    bounds,
    keys: complexKeys,
    optimizerOptions,
    parameterTransform: applyLinkedParameters,
    objectivePenalty: meanPenalty,
  }), counts, diagnosticMetadata);
  complex = attachPeakRegionProvenance(complex, initial, meanConfiguration?.peakRegions);
  complex = attachInitializationProvenance(complex, initialization, peakRegionsSource);

  const selection = selectSimpleVsComplex(simple, complex, { observationCount: counts.length });
  return {
    initialization,
    simple,
    complex,
    selection,
    selected: selection.selectedFit,
    peakRegions: meanConfiguration?.peakRegions,
    peakRegionsSource,
  };
}
