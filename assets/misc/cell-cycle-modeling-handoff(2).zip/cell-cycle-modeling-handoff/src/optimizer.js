import { clamp, poissonNll, variance } from './math.js';

function clipVector(vector, lower, upper) {
  return vector.map((value, i) => clamp(value, lower[i], upper[i]));
}

function distance(a, b) {
  let ss = 0;
  for (let i = 0; i < a.length; i += 1) ss += (a[i] - b[i]) ** 2;
  return Math.sqrt(ss);
}

/**
 * Dependency-free bounded Nelder-Mead optimizer.
 * Bounds are enforced by projection. For production, a tested trust-region or
 * L-BFGS-B implementation is preferable, but this is adequate as reference code.
 */
export function boundedNelderMead({
  objective,
  initial,
  lower,
  upper,
  step = null,
  maxIterations = 1500,
  xTolerance = 1e-7,
  fTolerance = 1e-7,
}) {
  const n = initial.length;
  if (lower.length !== n || upper.length !== n) throw new Error('Bounds must match initial vector length.');
  const x0 = clipVector(initial, lower, upper);
  const steps = step ?? x0.map((value, i) => Math.max(1e-3, 0.05 * Math.max(1, Math.abs(value), upper[i] - lower[i])));

  const simplex = [{ x: x0, f: safeObjective(objective, x0) }];
  for (let i = 0; i < n; i += 1) {
    const vertex = [...x0];
    vertex[i] = clamp(vertex[i] + steps[i], lower[i], upper[i]);
    if (vertex[i] === x0[i]) vertex[i] = clamp(vertex[i] - steps[i], lower[i], upper[i]);
    simplex.push({ x: vertex, f: safeObjective(objective, vertex) });
  }

  const alpha = 1;
  const gamma = 2;
  const rho = 0.5;
  const sigma = 0.5;
  let iterations = 0;

  for (; iterations < maxIterations; iterations += 1) {
    simplex.sort((a, b) => a.f - b.f);
    const best = simplex[0];
    const worst = simplex[n];
    const secondWorst = simplex[n - 1];

    const fVar = variance(simplex.map((vertex) => vertex.f));
    const maxDistance = Math.max(...simplex.slice(1).map((vertex) => distance(best.x, vertex.x)));
    if (Math.sqrt(Math.max(0, fVar)) < fTolerance && maxDistance < xTolerance) break;

    const centroid = new Array(n).fill(0);
    for (let i = 0; i < n; i += 1) {
      for (let j = 0; j < n; j += 1) centroid[j] += simplex[i].x[j] / n;
    }

    const reflectedX = clipVector(centroid.map((c, j) => c + alpha * (c - worst.x[j])), lower, upper);
    const reflected = { x: reflectedX, f: safeObjective(objective, reflectedX) };

    if (reflected.f < best.f) {
      const expandedX = clipVector(centroid.map((c, j) => c + gamma * (reflected.x[j] - c)), lower, upper);
      const expanded = { x: expandedX, f: safeObjective(objective, expandedX) };
      simplex[n] = expanded.f < reflected.f ? expanded : reflected;
      continue;
    }

    if (reflected.f < secondWorst.f) {
      simplex[n] = reflected;
      continue;
    }

    const outside = reflected.f < worst.f;
    const contractedX = clipVector(
      centroid.map((c, j) => c + rho * ((outside ? reflected.x[j] : worst.x[j]) - c)),
      lower,
      upper,
    );
    const contracted = { x: contractedX, f: safeObjective(objective, contractedX) };

    if (contracted.f < (outside ? reflected.f : worst.f)) {
      simplex[n] = contracted;
      continue;
    }

    for (let i = 1; i < simplex.length; i += 1) {
      const shrunkX = clipVector(simplex[i].x.map((value, j) => best.x[j] + sigma * (value - best.x[j])), lower, upper);
      simplex[i] = { x: shrunkX, f: safeObjective(objective, shrunkX) };
    }
  }

  simplex.sort((a, b) => a.f - b.f);
  return {
    x: simplex[0].x,
    value: simplex[0].f,
    iterations,
    converged: iterations < maxIterations,
  };
}

function safeObjective(objective, x) {
  try {
    const value = objective(x);
    return Number.isFinite(value) ? value : Number.MAX_VALUE / 100;
  } catch {
    return Number.MAX_VALUE / 100;
  }
}

export function objectToVector(object, keys) {
  return keys.map((key) => object[key]);
}

export function vectorToObject(vector, keys, base = {}) {
  const object = { ...base };
  keys.forEach((key, index) => {
    object[key] = vector[index];
  });
  return object;
}

export function fitHistogramModel({
  edges,
  counts,
  model,
  initial,
  bounds,
  keys = Object.keys(initial),
  modelOptions = {},
  optimizerOptions = {},
  normalizeBounds = true,
  parameterTransform = (params) => params,
  objectivePenalty = () => 0,
}) {
  const lower = keys.map((key) => bounds[key][0]);
  const upper = keys.map((key) => bounds[key][1]);
  const initialVector = objectToVector(initial, keys);

  const evaluate = (vector) => {
    const rawParams = vectorToObject(vector, keys, initial);
    const params = parameterTransform(rawParams);
    const penalty = objectivePenalty(params, rawParams);
    if (!Number.isFinite(penalty)) return Infinity;
    const expected = model(edges, params, modelOptions).total;
    return poissonNll(counts, expected) + penalty;
  };

  let optimization;
  let fittedVector;

  if (normalizeBounds) {
    // Optimize in a dimensionless unit cube. Cell-cycle parameters mix event
    // counts, channel positions, CVs, and polynomial coefficients; direct
    // simplex steps in raw units are otherwise badly scaled.
    const spans = lower.map((value, i) => Math.max(1e-12, upper[i] - value));
    const toUnit = (vector) => vector.map((value, i) => clamp((value - lower[i]) / spans[i], 0, 1));
    const fromUnit = (unit) => unit.map((value, i) => lower[i] + clamp(value, 0, 1) * spans[i]);
    const initialUnit = toUnit(initialVector);
    const objective = (unitVector) => evaluate(fromUnit(unitVector));

    const unitOptimization = boundedNelderMead({
      objective,
      initial: initialUnit,
      lower: new Array(keys.length).fill(0),
      upper: new Array(keys.length).fill(1),
      step: new Array(keys.length).fill(optimizerOptions.unitStep ?? 0.05),
      ...optimizerOptions,
    });
    fittedVector = fromUnit(unitOptimization.x);
    optimization = { ...unitOptimization, unitX: unitOptimization.x, x: fittedVector };
  } else {
    optimization = boundedNelderMead({
      objective: evaluate,
      initial: initialVector,
      lower,
      upper,
      ...optimizerOptions,
    });
    fittedVector = optimization.x;
  }

  const rawParams = vectorToObject(fittedVector, keys, initial);
  const params = parameterTransform(rawParams);
  const fittedModel = model(edges, params, modelOptions);
  return {
    ...optimization,
    params,
    rawParams,
    fittedModel,
    expected: fittedModel.total,
    parameterCount: keys.length,
    keys,
    bounds: Object.fromEntries(keys.map((key) => [key, bounds[key]])),
    allBounds: bounds,
  };
}
