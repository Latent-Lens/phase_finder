import {
  EPS,
  addArrays,
  binCenters,
  gaussianBinMass,
  normalCdf,
  normalizePositive,
  sum,
} from './math.js';

export function gaussianComponent(edges, { area, mean, sd }) {
  return gaussianBinMass(edges, area, mean, sd);
}

/**
 * Truncated exponential debris model.
 * Density is largest near min and decays toward cutoff.
 */
export function debrisComponent(edges, { area, rate, min = edges[0], cutoff = edges.at(-1) }) {
  const lambda = Math.max(EPS, rate);
  const lower = min;
  const upper = Math.max(lower + EPS, cutoff);
  const normalizer = 1 - Math.exp(-lambda * (upper - lower));
  const out = new Array(edges.length - 1).fill(0);

  function cdf(x) {
    if (x <= lower) return 0;
    if (x >= upper) return 1;
    return (1 - Math.exp(-lambda * (x - lower))) / normalizer;
  }

  for (let i = 0; i < out.length; i += 1) {
    const lo = Math.max(edges[i], lower);
    const hi = Math.min(edges[i + 1], upper);
    if (hi > lo) out[i] = Math.max(0, area) * Math.max(0, cdf(hi) - cdf(lo));
  }
  return out;
}

/**
 * A phenomenological sub-G1 component. DNA content alone does not prove
 * apoptosis; label it "sub-G1-like" unless an orthogonal apoptosis marker exists.
 */
export function subG1Component(edges, { area, mean, sd, upperCutoff }) {
  const raw = gaussianBinMass(edges, 1, mean, sd);
  const clipped = raw.map((value, i) => {
    const center = 0.5 * (edges[i] + edges[i + 1]);
    return center < upperCutoff ? value : 0;
  });
  return normalizePositive(clipped, Math.max(0, area));
}

/**
 * Self-convolution of a singlet DNA distribution to model unresolved doublets.
 * This is most useful when pulse geometry is unavailable; pulse geometry gating
 * should be preferred when it exists.
 */
export function aggregateDoubletComponent(edges, singletCounts, area) {
  const n = singletCounts.length;
  if (edges.length !== n + 1) throw new Error('Edges and singlet counts do not match.');
  const centers = binCenters(edges);
  const probabilities = normalizePositive(singletCounts, 1);
  const out = new Array(n).fill(0);
  const min = edges[0];
  const max = edges.at(-1);
  const width = (max - min) / n;

  for (let i = 0; i < n; i += 1) {
    if (probabilities[i] <= EPS) continue;
    for (let j = 0; j < n; j += 1) {
      if (probabilities[j] <= EPS) continue;
      const x = centers[i] + centers[j];
      if (x < min || x >= max) continue;
      const index = Math.min(n - 1, Math.max(0, Math.floor((x - min) / width)));
      out[index] += probabilities[i] * probabilities[j];
    }
  }
  return normalizePositive(out, Math.max(0, area));
}

export function addContaminants(baseModel, contaminants = {}) {
  const edges = baseModel.edges;
  const components = { ...baseModel.components };
  const extras = [];

  if (contaminants.debris?.area > 0) {
    components.debris = debrisComponent(edges, contaminants.debris);
    extras.push(components.debris);
  }
  if (contaminants.subG1?.area > 0) {
    components.subG1 = subG1Component(edges, contaminants.subG1);
    extras.push(components.subG1);
  }
  if (contaminants.aggregate?.area > 0) {
    const singlets = addArrays(
      baseModel.components.g1 ?? new Array(edges.length - 1).fill(0),
      baseModel.components.s ?? new Array(edges.length - 1).fill(0),
      baseModel.components.g2 ?? new Array(edges.length - 1).fill(0),
    );
    components.aggregate = aggregateDoubletComponent(edges, singlets, contaminants.aggregate.area);
    extras.push(components.aggregate);
  }

  return {
    ...baseModel,
    components,
    total: addArrays(baseModel.total, ...extras),
  };
}

/**
 * Combine multiple complete cell-cycle models, for example a diploid and a
 * tetraploid population. Each model should already include its intended area.
 */
export function multiplePloidyMixture(models) {
  if (!models.length) throw new Error('At least one ploidy model is required.');
  const edges = models[0].edges;
  for (const model of models) {
    if (model.edges.length !== edges.length) throw new Error('All ploidy models must share bin edges.');
  }

  const components = {};
  const totals = [];
  models.forEach((model, index) => {
    totals.push(model.total);
    for (const [name, values] of Object.entries(model.components)) components[`ploidy${index + 1}_${name}`] = values;
  });
  return { edges, total: addArrays(...totals), components };
}

export function componentAreas(model) {
  return Object.fromEntries(Object.entries(model.components).map(([name, values]) => [name, sum(values)]));
}
