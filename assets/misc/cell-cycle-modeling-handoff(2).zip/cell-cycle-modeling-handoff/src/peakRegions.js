import { binCenters, clamp, EPS, sum } from './math.js';
import { gaussianSmooth } from './histogram.js';

function finiteNumber(value, name) {
  if (!Number.isFinite(value)) throw new TypeError(`${name} must be a finite number.`);
  return value;
}

export function normalizePeakRegion(region, label = 'peak') {
  if (!region || typeof region !== 'object') {
    throw new TypeError(`${label} region is required.`);
  }
  const left = finiteNumber(region.left, `${label}.left`);
  const right = finiteNumber(region.right, `${label}.right`);
  if (!(left < right)) throw new RangeError(`${label} region must satisfy left < right.`);
  return {
    left,
    right,
    label: region.label ?? label,
    boundaryMeaning: region.boundaryMeaning ?? 'peak-window',
  };
}

/**
 * Validate semantic G1 and G2/M peak regions. The regions identify which
 * visible peak is which; they are not final cell-cycle phase gates.
 */
export function validatePeakRegions(peakRegions, options = {}) {
  const g1 = normalizePeakRegion(peakRegions?.g1, 'G1');
  const g2 = normalizePeakRegion(peakRegions?.g2, 'G2/M');
  const minimumGap = options.minimumGap ?? 0;
  if (!(g1.right + minimumGap <= g2.left)) {
    throw new RangeError('G1 and G2/M peak regions must be ordered and non-overlapping.');
  }
  return { g1, g2 };
}

function regionIndexes(centers, region) {
  const indexes = [];
  for (let i = 0; i < centers.length; i += 1) {
    if (centers[i] >= region.left && centers[i] <= region.right) indexes.push(i);
  }
  if (!indexes.length) {
    throw new RangeError(`${region.label} region does not contain any histogram bin centers.`);
  }
  return indexes;
}


function estimateSigmaOneSidedWithinRegion(values, peakIndex, indexes, fraction, side) {
  const peak = values[peakIndex];
  if (!(peak > 0)) return NaN;
  const threshold = peak * clamp(fraction, 0.05, 0.95);
  const first = indexes[0];
  const last = indexes.at(-1);
  let index = peakIndex;

  if (side === 'left') {
    while (index > first && values[index] > threshold) index -= 1;
  } else if (side === 'right') {
    while (index < last && values[index] > threshold) index += 1;
  } else {
    throw new Error("side must be 'left' or 'right'.");
  }

  // The threshold must be crossed before the selected region edge. Otherwise
  // the handle window did not expose enough of that shoulder for this method.
  if (values[index] > threshold) return NaN;
  const distanceBins = Math.abs(index - peakIndex);
  return distanceBins > 0 ? distanceBins / Math.sqrt(-2 * Math.log(fraction)) : NaN;
}

function localLinearBaseline(values, indexes) {
  const first = indexes[0];
  const last = indexes.at(-1);
  const leftValue = values[first];
  const rightValue = values[last];
  const denominator = Math.max(1, last - first);
  return indexes.map((index) => {
    const t = (index - first) / denominator;
    return leftValue + t * (rightValue - leftValue);
  });
}

/**
 * Estimate a peak center, width, and rough area using only bins inside a
 * user-selected peak region. The handles themselves are never modified.
 */
export function estimatePeakFromRegion(edges, counts, regionInput, options = {}) {
  const region = normalizePeakRegion(regionInput, options.label ?? 'peak');
  const centers = binCenters(edges);
  const binWidth = edges[1] - edges[0];
  const smoothed = options.smoothed ?? gaussianSmooth(counts, options.smoothingSigmaBins ?? 2);
  const indexes = regionIndexes(centers, region);

  let peakIndex = indexes[0];
  for (const index of indexes) {
    if (smoothed[index] > smoothed[peakIndex]) peakIndex = index;
  }

  const cleanSide = options.cleanSide ?? 'left';
  const sigmaBins = estimateSigmaOneSidedWithinRegion(smoothed, peakIndex, indexes, 0.5, cleanSide);
  let sigma = sigmaBins * binWidth;

  // If the one-sided estimate is unusable, fall back to a baseline-subtracted
  // second moment inside the region. The region span is only the last resort.
  if (!(sigma > 0) || !Number.isFinite(sigma)) {
    const baseline = localLinearBaseline(smoothed, indexes);
    const weights = indexes.map((index, i) => Math.max(0, smoothed[index] - baseline[i]));
    const weightSum = sum(weights);
    if (weightSum > EPS) {
      const centroid = sum(indexes.map((index, i) => weights[i] * centers[index])) / weightSum;
      const variance = sum(indexes.map((index, i) => weights[i] * (centers[index] - centroid) ** 2)) / weightSum;
      sigma = Math.sqrt(Math.max(EPS, variance));
    }
  }

  if (!(sigma > 0) || !Number.isFinite(sigma)) {
    const divisor = region.boundaryMeaning === 'fwhm' ? 2.354820045 : 4;
    sigma = Math.max(binWidth, (region.right - region.left) / divisor);
  }

  const edgeBaseline = Math.min(smoothed[indexes[0]], smoothed[indexes.at(-1)]);
  const height = Math.max(0, smoothed[peakIndex] - edgeBaseline);
  const area = Math.max(1, height * Math.sqrt(2 * Math.PI) * sigma / Math.max(EPS, binWidth));

  return {
    region,
    peakIndex,
    mean: centers[peakIndex],
    sigma,
    cv: sigma / Math.max(EPS, centers[peakIndex]),
    area,
    binIndexes: indexes,
  };
}

/**
 * Replace automatic peak identity/starts with user-defined peak regions while
 * keeping the handles immutable. The optimizer will later fit peak means
 * inside these regions.
 */
export function applyPeakRegionsToInitialization(
  initialization,
  edges,
  counts,
  peakRegionsInput,
  options = {},
) {
  const peakRegions = validatePeakRegions(peakRegionsInput, options);
  const updated = structuredClone(initialization);
  const smoothed = updated.smoothed ?? gaussianSmooth(counts, options.smoothingSigmaBins ?? 2);
  const g1 = estimatePeakFromRegion(edges, counts, peakRegions.g1, {
    smoothed,
    label: 'G1',
    cleanSide: 'left',
  });
  const g2 = estimatePeakFromRegion(edges, counts, peakRegions.g2, {
    smoothed,
    label: 'G2/M',
    cleanSide: 'right',
  });

  updated.params.g1Mean = clamp(g1.mean, peakRegions.g1.left, peakRegions.g1.right);
  updated.params.g2Mean = clamp(g2.mean, peakRegions.g2.left, peakRegions.g2.right);
  updated.params.ratio = updated.params.g2Mean / updated.params.g1Mean;

  if (options.reinitializeWidths ?? true) {
    updated.params.g1CV = clamp(g1.cv, 0.005, 0.35);
    updated.params.g2CV = clamp(g2.cv, 0.005, 0.35);
  }
  if (options.reinitializeAreas ?? false) {
    updated.params.g1Area = g1.area;
    updated.params.g2Area = g2.area;
  }

  updated.anchors = {
    ...updated.anchors,
    g1Mean: updated.params.g1Mean,
    g2Mean: updated.params.g2Mean,
    g1Range: [peakRegions.g1.left, peakRegions.g1.right],
    g2Range: [peakRegions.g2.left, peakRegions.g2.right],
    sRange: [updated.params.g1Mean, updated.params.g2Mean],
  };
  updated.peakRegionEstimates = { g1, g2 };
  updated.userPeakRegions = structuredClone(peakRegions);
  return updated;
}

function rangesOverlap(a, b) {
  return Math.max(a[0], b[0]) <= Math.min(a[1], b[1]);
}

/**
 * Build the mean-parameter portion of a constrained fit.
 *
 * - free/bounded modes fit g1Mean and g2Mean independently inside their
 *   semantic regions, then derive ratio = g2Mean / g1Mean.
 * - locked mode fits only g1Mean and derives g2Mean = lockedRatio * g1Mean.
 */
export function buildPeakMeanParameterization({
  initial,
  peakRegions: peakRegionsInput,
  ratioMode = 'bounded',
  ratioRange = [1.8, 2.15],
  lockedRatio = 2,
}) {
  const peakRegions = validatePeakRegions(peakRegionsInput);
  const g1Range = [peakRegions.g1.left, peakRegions.g1.right];
  const g2Range = [peakRegions.g2.left, peakRegions.g2.right];

  if (ratioMode === 'locked') {
    if (!(lockedRatio > 1)) throw new RangeError('lockedRatio must be greater than 1.');
    const feasibleG1 = [
      Math.max(g1Range[0], g2Range[0] / lockedRatio),
      Math.min(g1Range[1], g2Range[1] / lockedRatio),
    ];
    if (feasibleG1[0] > feasibleG1[1]) {
      throw new RangeError('Locked G2:G1 ratio is incompatible with the selected G1 and G2/M regions.');
    }
    const g1Mean = clamp(initial.g1Mean, feasibleG1[0], feasibleG1[1]);
    return {
      initial: { ...initial, g1Mean, g2Mean: lockedRatio * g1Mean, ratio: lockedRatio },
      meanKeys: ['g1Mean'],
      meanBounds: { g1Mean: feasibleG1 },
      parameterTransform: (params) => ({
        ...params,
        g2Mean: lockedRatio * params.g1Mean,
        ratio: lockedRatio,
      }),
      objectivePenalty: () => 0,
      peakRegions,
    };
  }

  const achievableRatioRange = [g2Range[0] / g1Range[1], g2Range[1] / g1Range[0]];
  if (ratioMode === 'bounded' && !rangesOverlap(achievableRatioRange, ratioRange)) {
    throw new RangeError(
      `Selected peak regions cannot satisfy the requested G2:G1 ratio range ` +
      `[${ratioRange[0]}, ${ratioRange[1]}].`,
    );
  }

  const g1Mean = clamp(initial.g1Mean, g1Range[0], g1Range[1]);
  const seededG2 = Number.isFinite(initial.g2Mean) ? initial.g2Mean : initial.ratio * g1Mean;
  const g2Mean = clamp(seededG2, g2Range[0], g2Range[1]);
  const transformedInitial = { ...initial, g1Mean, g2Mean, ratio: g2Mean / g1Mean };

  const objectivePenalty = (params) => {
    if (!(params.g2Mean > params.g1Mean)) return Infinity;
    if (ratioMode === 'bounded') {
      const ratio = params.g2Mean / params.g1Mean;
      if (ratio < ratioRange[0] || ratio > ratioRange[1]) return Infinity;
    }
    return 0;
  };

  return {
    initial: transformedInitial,
    meanKeys: ['g1Mean', 'g2Mean'],
    meanBounds: { g1Mean: g1Range, g2Mean: g2Range },
    parameterTransform: (params) => ({ ...params, ratio: params.g2Mean / params.g1Mean }),
    objectivePenalty,
    peakRegions,
  };
}

export function peakRegionBoundaryWarnings(params, peakRegionsInput, toleranceFraction = 0.02) {
  if (!peakRegionsInput) return [];
  const peakRegions = validatePeakRegions(peakRegionsInput);
  const warnings = [];
  for (const [key, region, label] of [
    ['g1Mean', peakRegions.g1, 'G1'],
    ['g2Mean', peakRegions.g2, 'G2/M'],
  ]) {
    if (!Number.isFinite(params[key])) continue;
    const span = Math.max(EPS, region.right - region.left);
    const atLeft = (params[key] - region.left) / span <= toleranceFraction;
    const atRight = (region.right - params[key]) / span <= toleranceFraction;
    if (atLeft || atRight) {
      warnings.push(
        `${label} fitted center reached the ${atLeft ? 'left' : 'right'} edge of its selected peak region; ` +
        'review or explicitly expand that region before refitting.',
      );
    }
  }
  return warnings;
}

export function summarizePeakRegionMigration(initialParams, fittedParams, peakRegionsInput) {
  const peakRegions = validatePeakRegions(peakRegionsInput);
  const summarize = (key, region) => {
    const start = initialParams[key];
    const end = fittedParams[key];
    const span = region.right - region.left;
    return {
      initial: start,
      fitted: end,
      absoluteShift: end - start,
      shiftAsRegionFraction: (end - start) / Math.max(EPS, span),
      selectedRegion: [region.left, region.right],
      handlesMoved: false,
    };
  };
  return {
    g1: summarize('g1Mean', peakRegions.g1),
    g2: summarize('g2Mean', peakRegions.g2),
  };
}
