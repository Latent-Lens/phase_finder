import { clamp, quantile } from './math.js';

export function buildHistogram(values, options = {}) {
  const finite = values.filter(Number.isFinite);
  if (!finite.length) throw new Error('No finite values were supplied.');

  const bins = Math.max(8, Math.floor(options.bins ?? 256));
  const min = options.min ?? quantile(finite, options.lowerQuantile ?? 0);
  const max = options.max ?? quantile(finite, options.upperQuantile ?? 1);
  if (!(max > min)) throw new Error('Histogram maximum must be greater than minimum.');

  const width = (max - min) / bins;
  const edges = Array.from({ length: bins + 1 }, (_, i) => min + i * width);
  const counts = new Array(bins).fill(0);
  let underflow = 0;
  let overflow = 0;

  for (const value of finite) {
    if (value < min) {
      underflow += 1;
      continue;
    }
    if (value > max) {
      overflow += 1;
      continue;
    }
    const index = value === max ? bins - 1 : Math.floor((value - min) / width);
    counts[clamp(index, 0, bins - 1)] += 1;
  }

  return { edges, counts, underflow, overflow, min, max, width, total: finite.length };
}

export function gaussianKernel(sigmaBins, radius = null) {
  const sigma = Math.max(0.25, sigmaBins);
  const r = radius ?? Math.max(1, Math.ceil(4 * sigma));
  const kernel = [];
  let total = 0;
  for (let i = -r; i <= r; i += 1) {
    const value = Math.exp(-0.5 * (i / sigma) ** 2);
    kernel.push(value);
    total += value;
  }
  return kernel.map((value) => value / total);
}

export function gaussianSmooth(values, sigmaBins = 2) {
  if (sigmaBins <= 0) return [...values];
  const kernel = gaussianKernel(sigmaBins);
  const radius = (kernel.length - 1) / 2;
  const out = new Array(values.length).fill(0);

  for (let i = 0; i < values.length; i += 1) {
    let weighted = 0;
    let mass = 0;
    for (let k = -radius; k <= radius; k += 1) {
      const j = i + k;
      if (j < 0 || j >= values.length) continue;
      const weight = kernel[k + radius];
      weighted += values[j] * weight;
      mass += weight;
    }
    out[i] = mass > 0 ? weighted / mass : values[i];
  }
  return out;
}

function localMinimum(values, start, end) {
  let minimum = Infinity;
  for (let i = Math.max(0, start); i <= Math.min(values.length - 1, end); i += 1) minimum = Math.min(minimum, values[i]);
  return minimum;
}

export function findLocalMaxima(values, options = {}) {
  const minHeight = options.minHeight ?? 0;
  const minDistance = Math.max(1, Math.floor(options.minDistance ?? 3));
  const prominenceWindow = Math.max(2, Math.floor(options.prominenceWindow ?? 12));
  const minProminence = options.minProminence ?? 0;
  const candidates = [];

  for (let i = 1; i < values.length - 1; i += 1) {
    if (values[i] < minHeight) continue;
    if (values[i] < values[i - 1] || values[i] < values[i + 1]) continue;
    const leftMin = localMinimum(values, i - prominenceWindow, i - 1);
    const rightMin = localMinimum(values, i + 1, i + prominenceWindow);
    const prominence = values[i] - Math.max(leftMin, rightMin);
    if (prominence < minProminence) continue;
    candidates.push({ index: i, height: values[i], prominence });
  }

  candidates.sort((a, b) => b.prominence - a.prominence || b.height - a.height);
  const selected = [];
  for (const candidate of candidates) {
    if (selected.every((peak) => Math.abs(peak.index - candidate.index) >= minDistance)) selected.push(candidate);
  }
  return selected.sort((a, b) => a.index - b.index);
}

export function estimatePeakSigma(values, peakIndex, fraction = 0.5) {
  const peak = values[peakIndex];
  if (!(peak > 0)) return 1;
  const threshold = peak * clamp(fraction, 0.05, 0.95);

  let left = peakIndex;
  while (left > 0 && values[left] > threshold) left -= 1;
  let right = peakIndex;
  while (right < values.length - 1 && values[right] > threshold) right += 1;

  const fullWidth = Math.max(1, right - left);
  const distanceAtFraction = Math.sqrt(-2 * Math.log(fraction));
  return fullWidth / (2 * distanceAtFraction);
}

export function integrateBins(counts, startIndex, endIndex) {
  let total = 0;
  for (let i = Math.max(0, startIndex); i <= Math.min(counts.length - 1, endIndex); i += 1) total += counts[i];
  return total;
}

/**
 * Estimate Gaussian sigma from only one side of a peak. This is useful for DNA
 * histograms because S phase contaminates the inner/right side of G1 and the
 * inner/left side of G2/M. `side` is 'left' or 'right'.
 */
export function estimatePeakSigmaOneSided(values, peakIndex, fraction = 0.5, side = 'left') {
  const peak = values[peakIndex];
  if (!(peak > 0)) return 1;
  const threshold = peak * clamp(fraction, 0.05, 0.95);
  let index = peakIndex;

  if (side === 'left') {
    while (index > 0 && values[index] > threshold) index -= 1;
  } else if (side === 'right') {
    while (index < values.length - 1 && values[index] > threshold) index += 1;
  } else {
    throw new Error("side must be 'left' or 'right'.");
  }

  const distance = Math.max(0.5, Math.abs(index - peakIndex));
  return distance / Math.sqrt(-2 * Math.log(fraction));
}
