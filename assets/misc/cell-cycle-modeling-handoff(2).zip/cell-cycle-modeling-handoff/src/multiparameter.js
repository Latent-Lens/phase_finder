import { EPS, interpolateBinValue, normalPdf, normalizePositive, quantile, sum } from './math.js';

export function estimateMarkerModels(markerValues, options = {}) {
  const finite = markerValues.filter(Number.isFinite);
  if (finite.length < 20) throw new Error('Too few finite marker values.');
  const negativeCut = quantile(finite, options.negativeQuantile ?? 0.4);
  const positiveCut = quantile(finite, options.positiveQuantile ?? 0.8);
  const negative = finite.filter((value) => value <= negativeCut);
  const positive = finite.filter((value) => value >= positiveCut);

  function moments(values) {
    const mean = sum(values) / values.length;
    const variance = values.reduce((acc, value) => acc + (value - mean) ** 2, 0) / Math.max(1, values.length - 1);
    return { mean, sd: Math.max(options.minimumSd ?? 1e-3, Math.sqrt(variance)) };
  }

  return {
    negative: moments(negative),
    positive: moments(positive),
    warning: 'Quantile-estimated marker distributions are fallback estimates; unstained and pulse-labeled controls are preferable.',
  };
}

/**
 * Event-level posterior probabilities for G1, S, and G2/M using a fitted DNA
 * model plus a replication marker such as EdU or BrdU.
 *
 * markerModels = {
 *   g1: {mean, sd}, s: {mean, sd}, g2: {mean, sd}
 * }
 * Usually G1 and G2 use the marker-negative control and S uses marker-positive.
 */
export function bivariatePhasePosteriors({ dnaValues, markerValues, edges, dnaComponents, markerModels }) {
  if (dnaValues.length !== markerValues.length) throw new Error('DNA and marker arrays must have the same length.');
  const phases = ['g1', 's', 'g2'];
  const areas = Object.fromEntries(phases.map((phase) => [phase, sum(dnaComponents[phase] ?? [])]));
  const totalArea = Math.max(EPS, sum(Object.values(areas)));
  const results = [];

  for (let i = 0; i < dnaValues.length; i += 1) {
    const dna = dnaValues[i];
    const marker = markerValues[i];
    if (!Number.isFinite(dna) || !Number.isFinite(marker)) {
      results.push({ g1: NaN, s: NaN, g2: NaN, phase: 'invalid' });
      continue;
    }

    const raw = phases.map((phase) => {
      // Convert the fitted component's expected bin count to p(DNA | phase).
      // Its component area is used separately as the phase prior, avoiding
      // accidental double-counting of abundant phases.
      const conditionalDnaMass = Math.max(
        EPS,
        interpolateBinValue(edges, dnaComponents[phase], dna) / Math.max(EPS, areas[phase]),
      );
      const markerModel = markerModels[phase];
      const markerDensity = Math.max(EPS, normalPdf(marker, markerModel.mean, markerModel.sd));
      const prior = Math.max(EPS, areas[phase] / totalArea);
      return prior * conditionalDnaMass * markerDensity;
    });
    const posterior = normalizePositive(raw, 1);
    const phaseIndex = posterior.indexOf(Math.max(...posterior));
    results.push({ g1: posterior[0], s: posterior[1], g2: posterior[2], phase: phases[phaseIndex] });
  }
  return results;
}

export function replicationMarkerModelsFromControls({ negativeControl, positiveControl, minimumSd = 1e-3 }) {
  function moments(values) {
    const finite = values.filter(Number.isFinite);
    if (finite.length < 5) throw new Error('Each marker control needs at least five finite events.');
    const mean = sum(finite) / finite.length;
    const variance = finite.reduce((acc, value) => acc + (value - mean) ** 2, 0) / Math.max(1, finite.length - 1);
    return { mean, sd: Math.max(minimumSd, Math.sqrt(variance)) };
  }
  const negative = moments(negativeControl);
  const positive = moments(positiveControl);
  return { g1: negative, s: positive, g2: negative };
}

/**
 * Generic extension for phase-associated markers (cyclins, phospho-markers,
 * RNA, budding status, etc.). Supply p(marker|phase) models and multiply them
 * with DNA-component likelihoods as above. Conditional independence is an
 * approximation; replace with a full multivariate density when needed.
 */
export function combineIndependentMarkerLikelihoods(phaseLikelihoods) {
  const phases = Object.keys(phaseLikelihoods);
  const raw = phases.map((phase) => phaseLikelihoods[phase].reduce((product, value) => product * Math.max(EPS, value), 1));
  const normalized = normalizePositive(raw, 1);
  return Object.fromEntries(phases.map((phase, index) => [phase, normalized[index]]));
}
