export function aic(logLikelihood, parameterCount) {
  return 2 * parameterCount - 2 * logLikelihood;
}

export function aicc(logLikelihood, parameterCount, observationCount) {
  const base = aic(logLikelihood, parameterCount);
  const denominator = observationCount - parameterCount - 1;
  return denominator > 0 ? base + (2 * parameterCount * (parameterCount + 1)) / denominator : Infinity;
}

export function bic(logLikelihood, parameterCount, observationCount) {
  return Math.log(observationCount) * parameterCount - 2 * logLikelihood;
}

export function scoreFit(fit, observationCount) {
  const ll = fit.diagnostics?.metrics?.logLikelihood ?? fit.logLikelihood;
  const k = fit.parameterCount;
  return {
    aic: aic(ll, k),
    aicc: aicc(ll, k, observationCount),
    bic: bic(ll, k, observationCount),
  };
}

function residualImprovement(baseFit, candidateFit, options = {}) {
  const baseMetrics = baseFit.diagnostics?.metrics ?? {};
  const candidateMetrics = candidateFit.diagnostics?.metrics ?? {};
  const baseDeviance = baseMetrics.reducedPoissonDeviance;
  const candidateDeviance = candidateMetrics.reducedPoissonDeviance;
  const baseLag = Math.abs(baseFit.diagnostics?.lag1Autocorrelation ?? NaN);
  const candidateLag = Math.abs(candidateFit.diagnostics?.lag1Autocorrelation ?? NaN);
  const minimumRelativeDevianceImprovement = options.minimumRelativeDevianceImprovement ?? 0.02;
  const minimumLagImprovement = options.minimumLagImprovement ?? 0.03;

  const devianceImproved = Number.isFinite(baseDeviance) && Number.isFinite(candidateDeviance)
    ? candidateDeviance <= baseDeviance * (1 - minimumRelativeDevianceImprovement)
    : true;
  const autocorrelationImproved = Number.isFinite(baseLag) && Number.isFinite(candidateLag)
    ? candidateLag <= Math.max(0, baseLag - minimumLagImprovement)
    : false;

  return {
    passed: devianceImproved || autocorrelationImproved,
    devianceImproved,
    autocorrelationImproved,
    baseReducedDeviance: baseDeviance,
    candidateReducedDeviance: candidateDeviance,
    baseAbsLag1: baseLag,
    candidateAbsLag1: candidateLag,
  };
}

/**
 * Conservative selection of DJF's complex S-phase wave over DJ.
 * The extra wave is retained only if BIC improves materially, its fitted
 * amplitude is nontrivial, it is not constraint-created, and residual
 * structure improves by at least one configured criterion.
 */
export function selectSimpleVsComplex(simpleFit, complexFit, options = {}) {
  const n = options.observationCount ?? simpleFit.expected.length;
  const simpleScores = scoreFit(simpleFit, n);
  const complexScores = scoreFit(complexFit, n);
  const deltaBic = simpleScores.bic - complexScores.bic;
  const waveAmplitude = complexFit.params.waveAmplitude ?? 0;
  const boundaryKeys = new Set(complexFit.diagnostics?.boundaryHits?.map((hit) => hit.key) ?? []);
  const waveAtBoundary = boundaryKeys.has('waveAmplitude') || boundaryKeys.has('waveMean') || boundaryKeys.has('waveSD');
  const minimumDeltaBic = options.minimumDeltaBic ?? 6;
  const minimumWaveAmplitude = options.minimumWaveAmplitude ?? 0.02;
  const residuals = residualImprovement(simpleFit, complexFit, options);

  const chooseComplex = deltaBic >= minimumDeltaBic
    && waveAmplitude >= minimumWaveAmplitude
    && !waveAtBoundary
    && residuals.passed;

  const reasons = [];
  if (chooseComplex) {
    reasons.push('Complex S-phase model materially improved BIC, residual structure, and component guardrails.');
  } else {
    if (deltaBic < minimumDeltaBic) reasons.push('BIC improvement was insufficient.');
    if (waveAmplitude < minimumWaveAmplitude) reasons.push('The fitted S-phase wave was too small.');
    if (waveAtBoundary) reasons.push('A wave parameter was at or near a constraint.');
    if (!residuals.passed) reasons.push('Residual structure did not improve enough.');
  }

  return {
    selected: chooseComplex ? 'complex' : 'simple',
    selectedFit: chooseComplex ? complexFit : simpleFit,
    simpleScores,
    complexScores,
    deltaBic,
    residualImprovement: residuals,
    reasons,
  };
}

/**
 * Generic forward-selection guardrail for debris, aggregate, sub-G1-like, or
 * an additional ploidy component. The caller specifies which candidate
 * parameter keys define the added component.
 */
export function selectAddedComponent(baseFit, candidateFit, options = {}) {
  const n = options.observationCount ?? baseFit.expected.length;
  const baseScores = scoreFit(baseFit, n);
  const candidateScores = scoreFit(candidateFit, n);
  const deltaBic = baseScores.bic - candidateScores.bic;
  const minimumDeltaBic = options.minimumDeltaBic ?? 6;
  const componentKeys = options.componentKeys ?? [];
  const componentAreaKey = options.componentAreaKey;
  const minimumArea = options.minimumArea ?? 0;
  const boundaryKeys = new Set(candidateFit.diagnostics?.boundaryHits?.map((hit) => hit.key) ?? []);
  const componentAtBoundary = componentKeys.some((key) => boundaryKeys.has(key));
  const area = componentAreaKey ? candidateFit.params[componentAreaKey] : Infinity;
  const residuals = residualImprovement(baseFit, candidateFit, options);

  const retained = deltaBic >= minimumDeltaBic
    && area >= minimumArea
    && !componentAtBoundary
    && residuals.passed;

  return {
    retained,
    selectedFit: retained ? candidateFit : baseFit,
    baseScores,
    candidateScores,
    deltaBic,
    area,
    componentAtBoundary,
    residualImprovement: residuals,
  };
}

export function rankCandidateModels(fits, observationCount) {
  return fits
    .map((fit) => ({ fit, ...scoreFit(fit, observationCount) }))
    .sort((a, b) => a.bic - b.bic);
}
