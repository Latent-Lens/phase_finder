import { EPS, mean, poissonDeviance, poissonLogLikelihood, sum } from './math.js';
import { peakRegionBoundaryWarnings } from './peakRegions.js';

export function pearsonResiduals(observed, expected) {
  return observed.map((value, i) => (value - expected[i]) / Math.sqrt(Math.max(EPS, expected[i])));
}

export function poissonDevianceResiduals(observed, expected) {
  return observed.map((value, i) => {
    const y = Math.max(0, value);
    const mu = Math.max(EPS, expected[i]);
    const contribution = y === 0 ? 2 * mu : 2 * (y * Math.log(y / mu) - (y - mu));
    return Math.sign(y - mu) * Math.sqrt(Math.max(0, contribution));
  });
}

export function lag1Autocorrelation(values) {
  if (values.length < 3) return NaN;
  const m = mean(values);
  let numerator = 0;
  let denominator = 0;
  for (let i = 0; i < values.length - 1; i += 1) numerator += (values[i] - m) * (values[i + 1] - m);
  for (const value of values) denominator += (value - m) ** 2;
  return denominator > EPS ? numerator / denominator : 0;
}

export function runsTestZ(values) {
  const signs = values.filter((value) => value !== 0).map((value) => value > 0 ? 1 : -1);
  if (signs.length < 4) return NaN;
  const nPos = signs.filter((value) => value > 0).length;
  const nNeg = signs.length - nPos;
  if (!nPos || !nNeg) return -Infinity;
  let runs = 1;
  for (let i = 1; i < signs.length; i += 1) if (signs[i] !== signs[i - 1]) runs += 1;
  const expected = 1 + (2 * nPos * nNeg) / (nPos + nNeg);
  const variance = (2 * nPos * nNeg * (2 * nPos * nNeg - nPos - nNeg)) /
    (((nPos + nNeg) ** 2) * (nPos + nNeg - 1));
  return variance > EPS ? (runs - expected) / Math.sqrt(variance) : NaN;
}

export function fitMetrics(observed, expected, parameterCount = 0) {
  const residuals = observed.map((value, i) => value - expected[i]);
  const rss = sum(residuals.map((value) => value * value));
  const rmse = Math.sqrt(rss / Math.max(1, observed.length));
  const dataMean = mean(observed);
  const pearson = pearsonResiduals(observed, expected);
  const pearsonChiSquare = sum(pearson.map((value) => value * value));
  const degreesOfFreedom = Math.max(1, observed.length - parameterCount);
  return {
    logLikelihood: poissonLogLikelihood(observed, expected),
    poissonDeviance: poissonDeviance(observed, expected),
    reducedPoissonDeviance: poissonDeviance(observed, expected) / degreesOfFreedom,
    pearsonChiSquare,
    reducedPearsonChiSquare: pearsonChiSquare / degreesOfFreedom,
    rmse,
    normalizedRmse: rmse / Math.max(EPS, dataMean),
    degreesOfFreedom,
  };
}

export function boundaryParameters(params, bounds, toleranceFraction = 0.01) {
  const hits = [];
  for (const [key, range] of Object.entries(bounds ?? {})) {
    if (!(key in params)) continue;
    const [lower, upper] = range;
    const span = Math.max(EPS, upper - lower);
    if ((params[key] - lower) / span <= toleranceFraction) hits.push({ key, side: 'lower' });
    if ((upper - params[key]) / span <= toleranceFraction) hits.push({ key, side: 'upper' });
  }
  return hits;
}

export function diagnoseFit({ observed, expected, params = {}, bounds = {}, parameterCount = 0, metadata = {} }) {
  const pearson = pearsonResiduals(observed, expected);
  const devianceResiduals = poissonDevianceResiduals(observed, expected);
  const metrics = fitMetrics(observed, expected, parameterCount);
  const lag1 = lag1Autocorrelation(devianceResiduals);
  const runsZ = runsTestZ(devianceResiduals);
  const boundaryHits = boundaryParameters(params, bounds);
  const warnings = [];

  if (metrics.reducedPoissonDeviance > 2) warnings.push('Poor global fit: reduced Poisson deviance is greater than 2.');
  if (Math.abs(lag1) > 0.25) warnings.push('Residuals show substantial lag-1 autocorrelation; model structure is probably missing.');
  if (Number.isFinite(runsZ) && runsZ < -2) warnings.push('Residual signs occur in long runs, suggesting systematic under/over-fit regions.');
  if (boundaryHits.length) warnings.push(`Parameters at or near constraints: ${boundaryHits.map((hit) => `${hit.key}:${hit.side}`).join(', ')}.`);
  if (Number.isFinite(params.ratio) && (params.ratio < 1.7 || params.ratio > 2.2)) warnings.push('G2:G1 peak ratio is far from the usual near-doubling expectation.');
  if (metadata.noPulseGeometry) warnings.push('No pulse-geometry channels were available; unresolved aggregates may inflate G2/M.');
  if (metadata.onlyOnePeak) warnings.push('Only one convincing DNA peak was detected; the second peak is strongly prior/constraint driven.');
  if (metadata.peakDetectionStatus === 'low_confidence') {
    warnings.push('Automatic G1/G2 peak identity was low confidence or ambiguous; review the selected regions and alternative pairs.');
  }
  if (metadata.peakRegions) warnings.push(...peakRegionBoundaryWarnings(params, metadata.peakRegions));

  return {
    metrics,
    pearsonResiduals: pearson,
    devianceResiduals,
    lag1Autocorrelation: lag1,
    runsTestZ: runsZ,
    boundaryHits,
    peakDetection: metadata.peakDetectionStatus ? {
      status: metadata.peakDetectionStatus,
      confidence: metadata.peakDetectionConfidence,
      peakRegionsSource: metadata.peakRegionsSource,
    } : undefined,
    warnings,
  };
}
