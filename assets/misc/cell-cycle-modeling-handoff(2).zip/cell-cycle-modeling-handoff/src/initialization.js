import { binCenters, clamp, sum } from './math.js';
import { estimatePeakSigmaOneSided } from './histogram.js';
import { detectCellCyclePeakPair } from './peakDetection.js';

/**
 * Hardened cell-cycle initialization. Automatic peak regions are proposals for
 * the UI; user-edited regions later become immutable semantic constraints.
 */
export function initializeCellCycle(edges, counts, options = {}) {
  const centers = binCenters(edges);
  const detectionResult = detectCellCyclePeakPair(edges, counts, options);
  const smoothed = detectionResult.primarySmoothed;
  const total = sum(counts);
  const binWidth = edges[1] - edges[0];
  const { detection } = detectionResult;
  const g1Index = detection.g1Index;
  const g2Index = detection.g2Index;

  // The outer sides are less contaminated by S phase. Prefer the multi-scale
  // peak measurement when available and otherwise estimate directly.
  const g1SigmaBins = detection.g1Candidate?.sigmaLeftBins
    ?? estimatePeakSigmaOneSided(smoothed, g1Index, 0.5, 'left');
  const g2SigmaBins = detection.g2Candidate?.sigmaRightBins
    ?? (g1SigmaBins * centers[g2Index] / Math.max(binWidth, centers[g1Index]));
  const g1Sd = Math.max(binWidth, g1SigmaBins * binWidth);
  const g2Sd = Math.max(binWidth, g2SigmaBins * binWidth);
  const g1Mean = centers[g1Index];
  const g2Mean = centers[g2Index];
  const ratioRange = options.ratioRange ?? [1.60, 2.35];
  const ratio = g2Mean / g1Mean;

  function outerBaselineAndArea(peakIndex, sigmaBins, side) {
    const radius = Math.max(3, Math.ceil(4 * sigmaBins));
    const start = side === 'left' ? Math.max(0, peakIndex - radius) : peakIndex;
    const end = side === 'left' ? peakIndex : Math.min(counts.length - 1, peakIndex + radius);
    let baseline = Infinity;
    for (let i = start; i <= end; i += 1) baseline = Math.min(baseline, smoothed[i]);
    const height = Math.max(0, smoothed[peakIndex] - baseline);
    const sd = sigmaBins * binWidth;
    return height * Math.sqrt(2 * Math.PI) * sd / binWidth;
  }

  const g1Area = outerBaselineAndArea(g1Index, g1SigmaBins, 'left');
  const g2Area = outerBaselineAndArea(g2Index, g2SigmaBins, 'right');
  const sArea = Math.max(0.02 * total, total - g1Area - g2Area);

  // Seed Fox's optional S-phase wave at the strongest interior feature after
  // excluding the immediate G1/G2 shoulders. The optimizer may shrink its
  // amplitude to zero when a simple DJ profile is sufficient.
  const interiorStart = Math.min(counts.length - 1, g1Index + Math.ceil(2 * g1SigmaBins));
  const interiorEnd = Math.max(0, g2Index - Math.ceil(2 * g2SigmaBins));
  let waveIndex = Math.floor((g1Index + g2Index) / 2);
  if (interiorEnd >= interiorStart) {
    waveIndex = interiorStart;
    for (let i = interiorStart; i <= interiorEnd; i += 1) {
      if (smoothed[i] > smoothed[waveIndex]) waveIndex = i;
    }
  }
  const waveMean = clamp((centers[waveIndex] - g1Mean) / Math.max(binWidth, g2Mean - g1Mean), 0.05, 0.95);
  const leftShoulder = smoothed[Math.min(smoothed.length - 1, interiorStart)];
  const rightShoulder = smoothed[Math.max(0, interiorEnd)];
  const shoulderLevel = 0.5 * (leftShoulder + rightShoulder);
  const relativeWaveHeight = Math.max(0, (smoothed[waveIndex] - shoulderLevel) / Math.max(1, shoulderLevel));
  const waveAmplitude = clamp(relativeWaveHeight, 0.15, 6);

  const warnings = [];
  if (detection.status === 'low_confidence') {
    warnings.push(
      'Automatic G1/G2 peak assignment is low confidence or ambiguous; review the proposed peak-region handles before fitting.',
    );
  } else if (detection.status === 'inferred_g2') {
    warnings.push(
      'No convincing G1/G2 peak pair was detected; G2/M was initialized from the expected G2:G1 ratio and must be reviewed.',
    );
  }

  const autoPeakRegions = detectionResult.autoPeakRegions;
  return {
    smoothed,
    smoothingScales: detectionResult.scaleResults.map((result) => result.scale),
    scaleSpace: detectionResult.scaleResults.map((result) => ({
      scale: result.scale,
      smoothed: result.smoothed,
      peaks: result.peaks,
    })),
    peaks: detectionResult.candidates,
    pairScores: detectionResult.pairs,
    detection,
    autoPeakRegions,
    peakDetectionConfiguration: detectionResult.configuration,
    anchors: {
      g1Index,
      g2Index,
      g1Mean,
      g2Mean,
      g1Range: [autoPeakRegions.g1.left, autoPeakRegions.g1.right],
      g2Range: [autoPeakRegions.g2.left, autoPeakRegions.g2.right],
      sRange: [g1Mean, g2Mean],
    },
    params: {
      g1Area: clamp(g1Area, 1, total),
      g1Mean,
      g1CV: clamp(g1Sd / g1Mean, 0.005, 0.35),
      g2Area: clamp(g2Area, 1, total),
      g2Mean,
      ratio: clamp(ratio, ratioRange[0], ratioRange[1]),
      g2CV: clamp(g2Sd / g2Mean, 0.005, 0.35),
      sArea: clamp(sArea, 1, total),
      s0: 0,
      s1: 0,
      s2: 0,
      waveAmplitude,
      waveMean,
      waveSD: 0.12,
    },
    warnings,
  };
}

/**
 * Legacy center-anchor adapter. New UIs should pass left/right peak regions
 * through `peakRegions`; these center anchors remain for compatibility.
 */
export function applyUserAnchors(initialization, userAnchors = {}) {
  const updated = structuredClone(initialization);
  const p = updated.params;
  if (Number.isFinite(userAnchors.g1Mean)) p.g1Mean = userAnchors.g1Mean;
  if (Number.isFinite(userAnchors.g2Mean)) {
    p.g2Mean = userAnchors.g2Mean;
    p.ratio = userAnchors.g2Mean / p.g1Mean;
  }
  if (Number.isFinite(userAnchors.ratio)) {
    p.ratio = userAnchors.ratio;
    p.g2Mean = p.ratio * p.g1Mean;
  }
  if (Number.isFinite(userAnchors.waveMeanDna)) {
    const g2Mean = p.ratio * p.g1Mean;
    p.waveMean = clamp((userAnchors.waveMeanDna - p.g1Mean) / (g2Mean - p.g1Mean), 0.02, 0.98);
  }
  updated.userAnchors = { ...userAnchors };
  return updated;
}
