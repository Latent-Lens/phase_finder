# Cell-cycle modeling implementation handoff

This bundle is a coding-agent handoff for implementing and documenting browser-based DNA-content cell-cycle analysis in JavaScript.

It contains:

- the recommended user-interface order;
- mathematical definitions of the Dean–Jett (DJ), Dean–Jett–Fox (DJF), Watson Pragmatic, and Orlando/CLOCCS models;
- dependency-free ES-module reference code;
- a hardened multi-scale automatic peak detector with explicit pair scoring, confidence, alternatives, inferred-peak states, and editable region proposals;
- modern additions for constraints, diagnostics, contaminant components, model selection, multiple ploidies, and replication-marker data;
- tests and a synthetic example;
- citations and BibTeX.

## Start here

1. Read [`AGENT_HANDOFF.md`](AGENT_HANDOFF.md).
2. Read [`UI_WORKFLOW.md`](UI_WORKFLOW.md).
3. Read [`AUTOMATIC_PEAK_DETECTION.md`](AUTOMATIC_PEAK_DETECTION.md) before implementing automatic G1/G2 proposals.
4. Read [`PEAK_REGION_HANDLES.md`](PEAK_REGION_HANDLES.md) before implementing manual G1/G2 controls.
5. Use [`MODEL_REFERENCE.md`](MODEL_REFERENCE.md) while implementing the fitting UI and reports.
6. Run:

```bash
npm test
npm run demo
npm run demo:peak-detection
```

## Important interpretation rules

1. **Automatic detection proposes regions; it does not silently settle ambiguous biology.** Preserve `detected`, `low_confidence`, and `inferred_g2` states plus ranked alternatives.
2. **User-drawn left/right G1 and G2/M regions identify semantic peaks and constrain fitted centers; they are not final phase gates.** The four handles never move during fitting, peak identity cannot swap, and final percentages come from fitted component areas.
3. **Fit histogram counts, not the display-only density curve.** A smoothed curve is useful for peak finding and visualization but should not replace observed counts in the likelihood.
4. **“Complex S-phase selected” is not proof that a culture was experimentally synchronized.** Synchronization is experimental metadata.
5. **DNA content alone does not prove apoptosis.** A fitted sub-G1 component must be labeled `sub-G1-like` unless supported by an orthogonal marker.
6. **CLOCCS is a synchronized time-series population-dynamics model.** It is not a drop-in replacement for fitting one histogram.
7. **The modern extensions are a modular engineering design, not one historically standardized successor called “DJF 2.0.”**

## Code status

The DJ, DJF, hardened peak-detection, histogram, component, diagnostic, and model-selection modules are runnable reference implementations. The CLOCCS module implements the published cohort/lifeline construction and a numerical forward model, but not the paper’s full Bayesian posterior sampler or original priors. Production validation against known software and published example datasets is still required.

## Directory map

```text
.
├── AGENT_HANDOFF.md
├── CHANGELOG.md
├── UI_WORKFLOW.md
├── AUTOMATIC_PEAK_DETECTION.md
├── PEAK_REGION_HANDLES.md
├── MODEL_REFERENCE.md
├── REFERENCES.md
├── references.bib
├── LICENSE
├── src/
│   ├── components.js
│   ├── diagnostics.js
│   ├── histogram.js
│   ├── initialization.js
│   ├── math.js
│   ├── modelSelection.js
│   ├── multiparameter.js
│   ├── optimizer.js
│   ├── peakDetection.js
│   ├── peakRegions.js
│   ├── pipeline.js
│   └── models/
│       ├── cloccs.js
│       ├── dj.js
│       ├── djf.js
│       ├── shared.js
│       ├── extended.js
│       └── watson.js
├── test/models.test.js
└── examples/
    ├── synthetic-demo.js
    ├── peak-detection-demo.js
    └── peak-region-demo.js
```
