# Changelog

## 0.4.0

Added hardened automatic G1/G2 peak detection and pair scoring.

- Added `src/peakDetection.js` with multi-scale Gaussian detection, peak persistence, location stability, prominence, half-prominence width, local area, and edge evidence.
- Added intrinsic-width deconvolution to downweight one-bin impulse artifacts that remain tall after smoothing.
- Added configurable G1/G2 pair scoring using expected ratio, prominence, area, width/CV compatibility, persistence, separation, S-phase bridge, and edge support.
- Added explicit `detected`, `low_confidence`, and `inferred_g2` states, heuristic confidence, ranked alternatives, and machine-readable reason codes.
- Added automatic editable peak-region proposals based on the cleaner G1-left and G2-right shoulders.
- Updated `fitAutoCellCycle()` to use accepted automatic regions by default while preserving whether regions came from automatic detection or the user.
- Added `AUTOMATIC_PEAK_DETECTION.md` with equations, JavaScript API, UI behavior, limitations, and validation requirements.
- Added a peak-detection demo and tests for sub-G1 distractors, one-bin impulses, multi-scale evidence, automatic handle placement, and ambiguous near-doubling pairs.
- Expanded the test suite to 18 passing tests.

## 0.3.0

Added explicit support for manual left/right G1 and G2/M peak regions.

- Added `PEAK_REGION_HANDLES.md` with UI semantics, equations, failure handling, and acceptance criteria.
- Added `src/peakRegions.js` for validation, region-based initialization, constrained mean parameterization, boundary warnings, and provenance.
- Updated DJ/DJF auto-fitting so manual regions constrain independently fitted G1 and G2/M centers without moving handles or swapping peak identity.
- Added bounded, free, and locked G2:G1 ratio behavior compatible with manual regions.
- Added optimizer hooks for transformed/coupled parameters and objective penalties.
- Added Watson Pragmatic support for the same immutable semantic peak regions.
- Added initial-to-final fitted-center migration summaries while explicitly recording that handles did not move.
- Added a peak-region demo and expanded the test suite to 13 tests.

## 0.2.0

Initial coding-agent handoff package with DJ, DJF, Watson Pragmatic, CLOCCS forward modeling, modern initialization, diagnostics, model selection, contaminants, multiple ploidies, and multiparameter marker analysis.
