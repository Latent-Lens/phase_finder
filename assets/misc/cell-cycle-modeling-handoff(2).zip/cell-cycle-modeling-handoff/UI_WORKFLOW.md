# Recommended UI and analysis order

## Core principle

The plot controls should help the optimizer start in the correct basin and optionally constrain biologically plausible ranges. They should not directly assign final G1, S, and G2/M percentages by hard-gated area.

## State sequence

```mermaid
flowchart TD
    A[Load FCS events] --> B[Validate channels and values]
    B --> C[Time QC and stable acquisition segments]
    C --> D[Main-cell and singlet filtering]
    D --> E[Build raw 1D DNA histogram]
    E --> F[Create display smoothing and auto-detect landmarks]
    F --> G[Show editable left/right peak regions and fit range]
    G --> H[Fit Watson, DJ, DJF or Auto model]
    H --> I[Fit optional contaminant components]
    I --> J[Model selection and residual diagnostics]
    J --> K[Overlay components and show warnings]
    K --> L{User accepts?}
    L -- No --> G
    L -- Yes --> M[Calculate fitted areas and phase percentages]
    M --> N[Export results, model settings, diagnostics and provenance]
```

## 1. Load and validate event-level data

Before constructing the DNA histogram:

- identify the DNA-area channel and any pulse-height or pulse-width channels;
- remove nonfinite events;
- remove values outside the instrument’s meaningful linear range when that range is known;
- keep event rows aligned across all channels when an event is removed;
- record every exclusion and surviving event count.

Do not silently transform a linear DNA channel to logarithmic scale. DJ/DJF assumes a DNA axis on which replicated DNA is approximately twice the G1 signal.

## 2. Perform event-level quality control

Recommended order:

1. time/acquisition stability;
2. main cell cloud using scatter when useful;
3. singlet discrimination using DNA-A versus DNA-H or DNA-W, preferably supplemented by scatter pulse geometry;
4. viability or experiment-specific exclusions.

Unresolved G1 doublets can overlap the G2/M DNA position. Therefore, pulse-geometry filtering is preferable to fixing the problem later with a histogram component.

## 3. Build the raw histogram

Use equal-width bins on the linear DNA axis. Store:

```js
{
  edges,       // n + 1 bin edges
  counts,      // n observed event counts
  totalEvents,
  underflow,
  overflow
}
```

Use the raw counts for likelihood fitting. A kernel-density estimate or smoothed histogram may be drawn for readability, but it must be labeled as display smoothing.

## 4. Auto-initialize landmarks

Run the hardened detector before showing manual controls:

1. smooth a copy of the histogram at several Gaussian scales;
2. find local maxima and measure prominence, half-prominence width, local area, and bases at each scale;
3. merge candidates that persist at stable locations across scales;
4. downweight one-bin impulse artifacts using deconvolved intrinsic width;
5. score every plausible ordered G1/G2 pair using ratio, prominence, area, width/CV compatibility, persistence, separation, S-phase bridge, and edge evidence;
6. retain ranked alternatives and calculate an explicit heuristic confidence;
7. create proposed left/right G1 and G2/M regions from the clean outer peak shoulders.

Present one of three states:

- `detected`: ordinary proposed regions;
- `low_confidence`: show the ambiguity and alternative pair assignments;
- `inferred_g2`: draw the proposed G2/M region differently and label it as inferred from the expected ratio.

The implementation is in `src/peakDetection.js` and `src/initialization.js`; the equations and output contract are in [`AUTOMATIC_PEAK_DETECTION.md`](AUTOMATIC_PEAK_DETECTION.md).

## 5. Show editable controls

Recommended primary controls:

- **G1 peak region**: draggable left and right handles surrounding the visible G1 peak;
- **G2/M peak region**: draggable left and right handles surrounding the visible G2/M peak;
- **fitted center markers**: separate, read-only markers showing where the optimizer placed each peak center inside its assigned region;
- **fit domain**: left and right limits for data included in fitting;
- **S-phase model**: `Auto`, `Simple`, or `Complex`;
- **G2:G1 ratio**: free, range-constrained, or locked;
- **equal peak CVs**: on/off;
- **contaminant components**: off/auto/manual for debris, sub-G1-like, and aggregates.

Advanced controls can expose CV ranges, component area bounds, and multiple-ploidy settings.

### What the handles mean

| Control | Correct interpretation |
|---|---|
| G1 left/right handles | Immutable semantic region identifying the visible G1 peak; fitted G1 center must remain inside |
| G2/M left/right handles | Immutable semantic region identifying the visible G2/M peak; fitted G2/M center must remain inside |
| Fitted center markers | Optimizer results that may move inside the assigned regions; they are not draggable region handles |
| S interval | Biological interval between fitted G1 and G2 means; not a hard count gate |
| Debris cutoff | Domain where an optional debris term may contribute |
| Display gates after fitting | Classification boundaries derived from fitted posterior/component intersections |


### Peak-region fitting rules

For user-selected regions \(G1=[L_1,R_1]\) and \(G2=[L_2,R_2]\), require:

\[
L_1\leq\mu_1\leq R_1,\qquad
L_2\leq\mu_2\leq R_2,\qquad
R_1\leq L_2.
\]

The four visible handles never migrate during fitting. Gaussian tails may extend outside the regions. If a fitted center reaches a region edge, retain the user selection and show a boundary warning rather than silently expanding or relabeling the peak. See [`PEAK_REGION_HANDLES.md`](PEAK_REGION_HANDLES.md) and `src/peakRegions.js`.

## 6. Fit models

Recommended default behavior:

1. fit DJ as the simple generative model;
2. fit DJF as the complex S-phase candidate;
3. compare them with Poisson likelihood criteria and residual structure;
4. retain DJF only if the wave is stable and materially improves the fit;
5. optionally evaluate contaminant components one at a time;
6. refit all retained parameters jointly.

Watson Pragmatic should remain available as a historically common alternative, but its residual-defined S phase makes direct AIC/BIC comparison with DJ/DJF inappropriate.

## 7. Display fit and residuals

Always display:

- observed histogram counts;
- total expected counts;
- G1, S, and G2/M components;
- optional contaminant components separately;
- Pearson or Poisson deviance residuals in a second panel;
- phase percentages and contaminant percentages;
- model name, parameter constraints, convergence state, and warnings.

The user should be able to accept the automatically proposed regions, adjust them, or reset them to automatic detection, then refit without rebuilding the event filters. Moving a handle invalidates the previous fit; percentages do not update until the user refits.

## 8. Calculate percentages

For fitted component arrays `G1_i`, `S_i`, and `G2_i`:

\[
N_{G1}=\sum_i G1_i,\qquad
N_S=\sum_i S_i,\qquad
N_{G2}=\sum_i G2_i
\]

The biological singlet denominator is:

\[
N_{bio}=N_{G1}+N_S+N_{G2}
\]

and the phase fractions are:

\[
p_{G1}=\frac{N_{G1}}{N_{bio}},\qquad
p_S=\frac{N_S}{N_{bio}},\qquad
p_{G2}=\frac{N_{G2}}{N_{bio}}.
\]

Debris, aggregates, and sub-G1-like components should be reported separately rather than silently included in the phase denominator.

## 9. Export provenance

Export at least:

- input filename and channel names;
- event counts before and after each QC step;
- histogram edges/counts;
- model type and software version;
- smoothing scales, detected candidates, candidate persistence/width evidence, ranked pair scores, confidence state, and alternatives;
- whether each automatic region was detected or inferred;
- initial values and final parameters;
- bounds and locked constraints;
- component areas and percentages;
- log likelihood, deviance, AICc/BIC where applicable;
- residual warnings;
- user edits, including the exact four peak-region handle positions;
- initial and fitted peak centers plus center movement within each selected region;
- confirmation that peak-region handles were not moved by the fitter;
- whether pulse geometry and replication markers were available.
