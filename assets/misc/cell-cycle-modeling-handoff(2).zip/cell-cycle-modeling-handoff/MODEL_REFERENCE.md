# Mathematical model and JavaScript reference

Citation keys refer to [`REFERENCES.md`](REFERENCES.md) and [`references.bib`](references.bib).

## 1. Observation model for histogram counts

Let bin \(i\) have edges \([b_i,b_{i+1})\), observed count \(y_i\), and expected count \(\lambda_i(\theta)\). A natural count likelihood is:

\[
y_i\sim\operatorname{Poisson}(\lambda_i(\theta)).
\]

Ignoring constants independent of the parameters, the log likelihood is:

\[
\ell(\theta)=\sum_i\left[y_i\log\lambda_i(\theta)-\lambda_i(\theta)\right].
\]

The optimizer minimizes \(-\ell(\theta)\). This is preferable to unweighted least squares because histogram variance increases with expected count. Fox’s original implementation minimized weighted squared deviations and used the Marquardt algorithm [Fox1980; Marquardt1963].

Implementation:

```js
import { poissonNll } from './src/math.js';

const loss = poissonNll(observedCounts, expectedCounts);
```

## 2. Gaussian G1 and G2/M peaks

For phase \(k\in\{1,2\}\):

\[
G_k(x)=\frac{N_k}{\sqrt{2\pi}\sigma_k}
\exp\left[-\frac{(x-\mu_k)^2}{2\sigma_k^2}\right],
\]

where:

- \(N_k\) is component area or expected cell count;
- \(\mu_k\) is the peak mean DNA signal;
- \(\sigma_k\) is its standard deviation;
- \(CV_k=\sigma_k/\mu_k\).

For bin fitting, integrate the Gaussian over each bin rather than evaluating only at the center:

\[
G_{k,i}=N_k\left[
\Phi\left(\frac{b_{i+1}-\mu_k}{\sigma_k}\right)-
\Phi\left(\frac{b_i-\mu_k}{\sigma_k}\right)
\right].
\]

Implementation: `gaussianBinMass()` in `src/math.js`.

## 3. Dean–Jett model

Dean and Jett modeled the total histogram as [DeanJett1974]:

\[
F(x)=G_1(x)+F_S(x)+G_2(x).
\]

### 3.1 Latent S-phase distribution

The unbroadened S-phase population is represented by a quadratic:

\[
f(u)=A+Bu+Cu^2,\qquad \mu_1\leq u\leq\mu_2.
\]

Here \(u\) is the true DNA-content position. The quadratic describes how many cells occupy each position between G1 and G2/M.

### 3.2 Constant-CV broadening

Each latent position is broadened by a normal distribution with the same coefficient of variation as G1:

\[
\sigma(u)=CV_1u=\sigma_1\frac{u}{\mu_1}.
\]

The observed S component is therefore:

\[
F_S(x)=\int_{\mu_1}^{\mu_2}f(u)
\frac{1}{\sqrt{2\pi}\sigma(u)}
\exp\left[-\frac{(x-u)^2}{2\sigma(u)^2}\right]du.
\]

The code approximates this integral with a sum across latent histogram positions.

```js
import { djExpectedCounts } from './src/models/dj.js';

const model = djExpectedCounts(edges, {
  g1Area: 5000,
  g1Mean: 70,
  g1CV: 0.06,
  g2Area: 1800,
  ratio: 2.0,
  g2CV: 0.06,
  sArea: 3200,
  s0: 0,
  s1: 0.5,
  s2: -0.2
});
```

### Stable implementation detail

An unconstrained quadratic can become negative. The default implementation uses:

\[
f(z)=\operatorname{softplus}(a+bz+cz^2),\qquad z=\frac{u-\mu_1}{\mu_2-\mu_1},
\]

then normalizes the profile to \(N_S\). This preserves the DJ shape class while preventing negative expected counts. Set `{stable: false}` only for historical comparison, not production fitting.

## 4. Dean–Jett–Fox model

Fox extended the latent S-phase profile for synchronized or otherwise complex S-phase populations [Fox1980]:

\[
f(u)=A+Bu+Cu^2+
\frac{N_W}{\sqrt{2\pi}\sigma_W}
\exp\left[-\frac{(u-\mu_W)^2}{2\sigma_W^2}\right].
\]

The Gaussian wave is part of the **latent biological distribution**. The entire latent profile is then broadened with the constant-CV kernel from the DJ model:

\[
F_S(x)=\int_{\mu_1}^{\mu_2}f(u)\,\phi(x;u,CV_1u)\,du.
\]

This distinction matters:

- \(\mu_W,\sigma_W,N_W\) describe a concentrated cohort within S phase;
- \(CV_1u\) describes measurement and biological dispersion around each DNA position.

Implementation:

```js
import { djfExpectedCounts } from './src/models/djf.js';

const model = djfExpectedCounts(edges, {
  ...djParameters,
  waveAmplitude: 4,
  waveMean: 0.62, // normalized position between G1 and G2
  waveSD: 0.08
});
```

The code uses normalized S coordinate \(z\in[0,1]\), which makes constraints independent of channel scale.

## 5. Watson Pragmatic model

Watson, Chambers, and Smith proposed a deliberately pragmatic method requiring an identifiable G1 or G2/M peak [Watson1987]. FlowJo’s documented implementation:

1. finds the dominant G1 candidate in the left portion of the histogram;
2. estimates width near 60% of peak height;
3. improves the G1 Gaussian fit using an asymmetric local range extending farther left than right;
4. initializes G2/M near \(1.75\mu_1\), then fits its Gaussian;
5. derives S phase from counts remaining between the fitted peaks.

A practical discrete representation is:

\[
S_i=\begin{cases}
\max(0,y_i-G_{1,i}-G_{2,i}), & \mu_1<x_i<\mu_2,\\
0, & \text{otherwise.}
\end{cases}
\]

Implementation:

```js
import { fitWatsonPragmatic } from './src/models/watson.js';

const fit = fitWatsonPragmatic({
  edges,
  counts,
  peakRegions: {
    g1: { left: 60, right: 82 },
    g2: { left: 128, right: 152 }
  }
});
```

### Important limitation

When manual peak regions are supplied, Watson locally fits each Gaussian using the assigned region and keeps each fitted mean inside that region; the four handles remain unchanged. Watson’s S component is data residual, not a fully parameterized probability density. It is useful as an alternative estimate, but do not rank it against DJ/DJF using ordinary AIC/BIC as though all models had equivalent likelihood structures.

## 6. Orlando/CLOCCS branching-process model

CLOCCS models loss of synchrony across an entire time series, not merely the shape of one histogram [Orlando2009]. It represents cells on a linearized cell-cycle “lifeline.”

### 6.1 Core parameters

\[
\Theta=(\mu_0,\sigma_0^2,\sigma_v^2,\lambda,\delta),
\]

where:

- \(\lambda\): typical mother-cell cycle length;
- \(\mu_0,\sigma_0\): mean and spread of recovery/initial position after release;
- \(\sigma_v\): variation in cell-cycle velocity;
- \(\delta\): daughter-specific first-cycle delay.

### 6.2 Cohort position

A cohort is indexed by generation \(g\) and reproductive instance \(r\). Its position is:

\[
P_t=P_0+Vt-g\delta-r\lambda.
\]

Therefore:

\[
P_t\mid g,r,t\sim N\left(
-\mu_0+t-g\delta-r\lambda,
\sigma_0^2+t^2\sigma_v^2
\right),
\]

with descendant cohorts truncated at \(P_t\geq-\delta\).

The population position distribution is a cohort mixture:

\[
p(P_t\mid\Theta,t)=\sum_{(g,r)\in\mathcal C}
 p(P_t\mid\Theta,g,r,t)p(g,r\mid\Theta,t).
\]

The included implementation uses the cohort survival masses and lineage multiplicity:

\[
M_{g,r}(t)=\binom{r-1}{g-1}
\Pr\left(P_0+Vt\geq r\lambda+(g-1)\delta\right),
\]

then normalizes these masses to mixture weights.

### 6.3 Position-to-DNA mapping

Let \(\gamma_1\) and \(\gamma_2\) be the fractions of the cycle where S phase begins and ends. Let \(\alpha_1\) be G1 fluorescence and \(\alpha_2\) be the increase from G1 to G2/M. Expected DNA fluorescence is:

\[
m(P_t)=\begin{cases}
\alpha_1, & \text{G1},\\
\alpha_1+\alpha_2\dfrac{q-\gamma_1}{\gamma_2-\gamma_1}, & \text{S},\\
\alpha_1+\alpha_2, & \text{G2/M},
\end{cases}
\]

where \(q\) is fractional position within the current cycle. Measurement noise is:

\[
Y\mid P_t\sim N(m(P_t),\tau_t^2).
\]

Thus:

\[
p(Y\mid t)=\int p(Y\mid P_t)p(P_t\mid t)dP_t.
\]

Implementation:

```js
import { cloccsExpectedHistogramAtTime } from './src/models/cloccs.js';

const expected = cloccsExpectedHistogramAtTime(
  edges,
  90,
  { mu0: 15, sigma0: 5, sigmaV: 0.05, lambda: 80, delta: 20, maxCycles: 4 },
  { alpha1: 70, alpha2: 70, tau: 4, gamma1: 0.25, gamma2: 0.55, totalEvents: 10000 }
);
```

### Scope warning

The module is a numerical forward model and likelihood scaffold. Reproducing Orlando et al.’s full Bayesian analysis requires validated priors, posterior sampling, convergence diagnostics, and joint handling of time-specific nuisance parameters and budding-index data.

## 7. Automatic initialization

Initialization proposes editable G1/G2 peak regions and starting parameters. It does not make irreversible phase assignments. The hardened implementation is documented fully in [`AUTOMATIC_PEAK_DETECTION.md`](AUTOMATIC_PEAK_DETECTION.md) and implemented in `src/peakDetection.js` plus `src/initialization.js`.

### 7.1 Multi-scale peak evidence

For several Gaussian smoothing scales \(\sigma_s\):

\[
H_{\sigma_s}(i)=\sum_k H(i-k)K_{\sigma_s}(k),
\qquad
K_{\sigma_s}(k)\propto
\exp\left(-\frac{k^2}{2\sigma_s^2}\right).
\]

Local maxima are measured using prominence, half-prominence width, approximate area, persistence across scales, and location stability. A deconvolved intrinsic-width estimate downweights one-bin impulse artifacts:

\[
\widehat\sigma_{intrinsic,s}=
\sqrt{\max(0,\widehat\sigma_{observed,s}^2-\sigma_s^2)}.
\]

### 7.2 G1/G2 pair score

Every ordered candidate pair in a broad allowed ratio range receives normalized evidence scores for:

- agreement with the expected G2:G1 ratio;
- peak prominence and area;
- persistence across smoothing scales;
- width/CV compatibility;
- peak separation;
- continuous S-phase bridge evidence;
- distance from histogram boundaries.

The default total score is:

\[
Q(i,j)=
0.28q_R+0.14q_P+0.09q_A+0.09q_W+
0.14q_{persist}+0.08q_D+0.12q_B+0.06q_E.
\]

These weights are configurable software defaults, not constants from the historical DJ/DJF publications.

### 7.3 Confidence and inferred peaks

The best score, its margin over alternatives, a softmax ranking share, and candidate quality produce a heuristic confidence. Results are explicitly labeled:

- `detected`;
- `low_confidence` when competing assignments are close or evidence is weak;
- `inferred_g2` when G2/M must be proposed from the expected ratio.

```js
import { detectCellCyclePeakPair } from './src/index.js';

const automatic = detectCellCyclePeakPair(edges, counts, {
  smoothingScales: [1, 2, 4],
  expectedRatio: 2,
  ratioRange: [1.60, 2.35]
});

console.log(automatic.detection.status);
console.log(automatic.detection.confidence);
console.log(automatic.autoPeakRegions);
```

The automatic regions are displayed as editable proposals. Once accepted or edited by the user, the fitting rules below apply.

### 7.4 Manual left/right peak regions

When a user marks the left and right sides of the G1 and G2/M peaks, interpret the selections as semantic peak regions:

\[
G1=[L_1,R_1],\qquad G2=[L_2,R_2].
\]

The selected handles remain fixed. Fit the centers under:

\[
L_1\leq\mu_1\leq R_1,
\qquad
L_2\leq\mu_2\leq R_2,
\qquad
\mu_1<\mu_2.
\]

The Gaussian components are not truncated at the handles; their tails may extend outside the selected regions.

For a bounded G2:G1 ratio:

\[
R_{min}\leq\frac{\mu_2}{\mu_1}\leq R_{max}.
\]

The selected regions can satisfy this only when the achievable interval

\[
\left[\frac{L_2}{R_1},\frac{R_2}{L_1}\right]
\]

overlaps `[R_min,R_max]`.

For a locked ratio \(R\), derive \(\mu_2=R\mu_1\) and restrict \(\mu_1\) to:

\[
\left[
\max\left(L_1,\frac{L_2}{R}\right),
\min\left(R_1,\frac{R_2}{R}\right)
\right].
\]

An empty interval is a constraint conflict and fitting must stop rather than moving a handle.

```js
import { fitAutoCellCycle } from './src/index.js';

const result = fitAutoCellCycle({
  edges,
  counts,
  peakRegions: {
    g1: { left: 60, right: 82 },
    g2: { left: 128, right: 152 }
  },
  constraints: {
    ratioMode: 'bounded',
    ratioRange: [1.8, 2.2]
  }
});
```

`src/peakRegions.js` initializes each peak from data inside its region, constructs a mean parameterization that cannot swap peak identities, adds edge warnings, and exports center movement separately from the unchanged handles. See [`PEAK_REGION_HANDLES.md`](PEAK_REGION_HANDLES.md).

## 8. Constrained optimization

### 8.1 Recommended constraints

- \(N_{G1},N_S,N_{G2}\geq0\);
- \(\sigma_k>0\);
- \(1.65\lesssim\mu_2/\mu_1\lesssim2.25\), unless the assay justifies otherwise;
- \(0<\mu_W<1\) on normalized S position;
- \(0<\sigma_W<0.5\);
- contaminant component areas nonnegative;
- multiple-ploidy means ordered to prevent label switching;
- when manual peak regions exist, fit each peak center inside its assigned left/right region and never migrate those handles.

### 8.2 Equality and soft constraints

Examples:

\[
CV_2=CV_1
\]

or a soft penalty:

\[
\mathcal L_{pen}= -\ell(\theta)+
\lambda_R\left(\frac{\mu_2}{\mu_1}-R_0\right)^2.
\]

Use equality constraints when the experiment or control sample establishes the relationship. Use soft penalties when modest deviation is plausible.

### 8.3 Code

`src/optimizer.js` contains a dependency-free bounded Nelder–Mead implementation and `fitHistogramModel()`. The fitter accepts `parameterTransform` and `objectivePenalty` hooks so region-constrained means, derived ratios, locked ratios, and coupled feasibility rules can be expressed without pretending they are independent box bounds. It is reference code, not a claim that Nelder–Mead is optimal. A production implementation may replace it with a tested bounded trust-region, Levenberg–Marquardt with transformations, or L-BFGS-B optimizer.

## 9. Residual checking

### 9.1 Pearson residual

\[
r_i^{(P)}=\frac{y_i-\lambda_i}{\sqrt{\lambda_i}}.
\]

### 9.2 Poisson deviance residual

\[
r_i^{(D)}=\operatorname{sign}(y_i-\lambda_i)
\sqrt{2\left[y_i\log\left(\frac{y_i}{\lambda_i}\right)-(y_i-\lambda_i)\right]}.
\]

For \(y_i=0\), the expression becomes \(-\sqrt{2\lambda_i}\).

### 9.3 Structural checks

Report:

- reduced Poisson deviance;
- residual lag-1 autocorrelation;
- runs-test statistic for long same-sign regions;
- maximum regional residual sum;
- parameters at bounds;
- G2:G1 ratio warning;
- missing pulse-geometry warning;
- one-visible-peak warning.

A visually good overlay can still hide systematic residual structure. Always show the residual panel.

Implementation: `src/diagnostics.js`.

## 10. Debris component

A simple phenomenological left-side debris density is a truncated exponential:

\[
D(x)=\frac{N_D\lambda e^{-\lambda(x-x_{min})}}
{1-e^{-\lambda(x_c-x_{min})}},
\qquad x_{min}\leq x\leq x_c.
\]

Use only when residuals show systematic excess toward low DNA and event-level QC cannot remove it. Debris should be reported separately from biological cell-cycle phases.

Implementation: `debrisComponent()` in `src/components.js`.

## 11. Sub-G1-like/apoptosis component

A basic sub-G1-like component can be represented as a Gaussian truncated below the fitted G1 mean:

\[
A_{sub}(x)\propto
\phi(x;\mu_A,\sigma_A)I(x<\mu_1).
\]

This is intentionally labeled **sub-G1-like**, not apoptosis. DNA fragmentation can create sub-G1 signal, but debris can do the same, and early apoptotic cells can overlap ordinary G1. Use Annexin V, caspase activity, TUNEL, or another orthogonal marker when apoptosis is a biological endpoint [Nicoletti1991; FlowJoHints].

Implementation: `subG1Component()`.

## 12. Aggregate/doublet component

When two independent singlets pass together, their measured DNA-area signal is approximately the sum of their signals. If \(B(x)\) is the normalized singlet biological distribution, the unresolved doublet model is:

\[
A(x)=N_A(B*B)(x)=N_A\int B(u)B(x-u)du.
\]

This naturally places G1+G1 doublets near the G2/M signal. It is a useful fallback if pulse geometry is unavailable, but it cannot perfectly separate true G2/M from G1 doublets on DNA area alone [Wersto2001].

Implementation: `aggregateDoubletComponent()`.

## 13. Multiple-ploidy populations

For \(K\) cycling ploidy populations:

\[
F(x)=\sum_{k=1}^{K}\pi_kF_k(x;\theta_k)+C(x),
\qquad \pi_k\geq0,
\]

where each \(F_k\) may be DJ or DJF and \(C(x)\) contains contaminants.

Recommended constraints:

- ordered G1 means \(\mu_{1,1}<\mu_{1,2}<\cdots\);
- optional near-integer relationships such as \(\mu_{1,2}\approx2\mu_{1,1}\);
- shared or tightly related CVs when justified;
- minimum area for each retained ploidy population;
- require a substantial information-criterion and residual improvement.

Multiple ploidy is often weakly identifiable from a single histogram because one population’s G1 can overlap another population’s G2/M.

Implementation: `multiplePloidyMixture()`.

## 14. Model selection

For a maximized log likelihood \(\hat\ell\), parameter count \(k\), and \(n\) bins:

\[
AIC=2k-2\hat\ell,
\]

\[
AIC_c=AIC+\frac{2k(k+1)}{n-k-1},
\]

\[
BIC=k\log n-2\hat\ell.
\]

Recommended simple-versus-complex S-phase rule:

1. fit DJ and DJF from comparable starts;
2. require \(\Delta BIC=BIC_{DJ}-BIC_{DJF}\geq6\) by default;
3. require a nontrivial wave amplitude;
4. reject the wave if its amplitude, mean, or width sits on a constraint;
5. require improved residual structure, not only lower scalar loss;
6. otherwise retain DJ.

Because “no extra component” places an amplitude on a boundary at zero, standard asymptotic likelihood-ratio assumptions can fail. Parametric bootstrap is the more rigorous option for important studies.

Implementation: `src/modelSelection.js`.

## 15. Multiparameter EdU/BrdU or other-marker analysis

### 15.1 Bivariate phase model

For DNA signal \(d\), marker signal \(m\), and phase \(c\in\{G1,S,G2\}\):

\[
p(d,m)=\sum_c\pi_c p(d\mid c)p(m\mid c).
\]

A simple implementation assumes conditional independence within phase:

\[
p(d,m\mid c)=p(d\mid c)p(m\mid c).
\]

For EdU/BrdU pulse labeling:

- \(p(m\mid S)\) is estimated from marker-positive cells or a labeled control;
- \(p(m\mid G1)\) and \(p(m\mid G2)\) use the negative-control distribution;
- \(p(d\mid c)\) comes from fitted DJ/DJF component mass.

Event-level posterior membership is:

\[
P(c\mid d,m)=
\frac{\pi_c p(d\mid c)p(m\mid c)}
{\sum_j\pi_j p(d\mid j)p(m\mid j)}.
\]

Implementation:

```js
import {
  bivariatePhasePosteriors,
  replicationMarkerModelsFromControls
} from './src/multiparameter.js';

const markerModels = replicationMarkerModelsFromControls({
  negativeControl,
  positiveControl
});

const membership = bivariatePhasePosteriors({
  dnaValues,
  markerValues,
  edges,
  dnaComponents: fittedModel.components,
  markerModels
});
```

BrdU/DNA bivariate flow cytometry directly identifies DNA-synthesizing cells, and EdU click chemistry provides a related replication marker without antibody-mediated BrdU detection [Dolbeare1983; Salic2008].

### 15.2 Other markers

The same framework can incorporate:

- cyclins;
- phospho-histone H3 for mitosis;
- RNA content;
- viability or apoptosis markers;
- yeast budding status;
- size or morphology measurements.

Conditional independence is only a starting approximation. Replace it with phase-specific multivariate Gaussian, Gaussian-mixture, kernel, or copula densities when marker correlations matter.

## 16. Percentages and contamination reporting

Let component areas be:

\[
N_{G1}=\sum_iG_{1,i},\quad
N_S=\sum_iS_i,\quad
N_{G2}=\sum_iG_{2,i}.
\]

Biological phase fractions use:

\[
N_{bio}=N_{G1}+N_S+N_{G2}.
\]

Report contaminants separately:

\[
p_{debris}=\frac{N_D}{N_{all}},\quad
p_{aggregate}=\frac{N_A}{N_{all}},\quad
p_{subG1}=\frac{N_{sub}}{N_{all}}.
\]

Do not quietly normalize contaminant components into the G1/S/G2 denominator.

## 17. Uncertainty

A practical browser-compatible method is parametric bootstrap:

1. fit the selected model;
2. generate synthetic histogram counts \(y_i^*\sim\operatorname{Poisson}(\hat\lambda_i)\);
3. refit each synthetic histogram;
4. summarize parameter and phase-fraction quantiles;
5. report failed or boundary-hitting refits.

Bootstrap intervals reflect model and counting uncertainty but not unmodeled sample preparation or gating bias.

## 18. Joint extended-model wrapper

`src/models/extended.js` combines a DJ or DJF biological model with explicitly enabled debris, aggregate, and sub-G1-like components. This produces one expected-count vector so all active areas and shapes can be refit jointly:

```js
import {
  djfExpectedCounts,
  extendedCellCycleExpectedCounts,
  fitHistogramModel
} from './src/index.js';

const enabled = { debris: true, aggregate: true, subG1: false };
const model = (edges, params) => extendedCellCycleExpectedCounts(edges, params, {
  baseModel: djfExpectedCounts,
  enabled,
  debrisCutoff: params.g1Mean
});

const fit = fitHistogramModel({
  edges,
  counts,
  model,
  initial,
  bounds,
  keys: [
    'g1Area', 'g1Mean', 'g1CV',
    'g2Area', 'ratio', 'g2CV',
    'sArea', 's0', 's1', 's2',
    'waveAmplitude', 'waveMean', 'waveSD',
    'debrisArea', 'debrisRate', 'aggregateArea'
  ]
});
```

Enable components deliberately so the parameter count used by AICc/BIC is explicit. Do not leave every optional component active by default. `selectAddedComponent()` in `src/modelSelection.js` provides a conservative forward-selection guardrail using BIC, residual improvement, minimum area, and boundary checks.
