import {
  componentAreas,
  diagnoseFit,
  djfExpectedCounts,
  initializeCellCycle,
  sum,
} from '../src/index.js';

const edges = Array.from({ length: 257 }, (_, i) => i);
const params = {
  g1Area: 5000,
  g1Mean: 70,
  g1CV: 0.055,
  g2Area: 1800,
  ratio: 1.98,
  g2CV: 0.06,
  sArea: 3200,
  s0: 0,
  s1: 0.8,
  s2: -0.4,
  waveAmplitude: 4,
  waveMean: 0.62,
  waveSD: 0.08,
};

const model = djfExpectedCounts(edges, params);
const initialization = initializeCellCycle(edges, model.total);
const diagnostics = diagnoseFit({
  observed: model.total,
  expected: model.total,
  params,
  bounds: {},
  parameterCount: 13,
});

console.log(JSON.stringify({
  totalEvents: sum(model.total),
  componentAreas: componentAreas(model),
  initialization: initialization.params,
  diagnostics: diagnostics.metrics,
}, null, 2));
