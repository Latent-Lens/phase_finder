import {
  addArrays,
  detectCellCyclePeakPair,
  djExpectedCounts,
  gaussianBinMass,
} from '../src/index.js';

const edges = Array.from({ length: 257 }, (_, i) => i);
const biological = djExpectedCounts(edges, {
  g1Area: 5000,
  g1Mean: 70,
  g1CV: 0.06,
  g2Area: 1800,
  ratio: 2,
  g2CV: 0.06,
  sArea: 3200,
  s0: 0,
  s1: 0.5,
  s2: -0.2,
}).total;

// Add a narrow sub-G1 distractor. The continuous S-phase bridge should still
// make the biological 70/140 pair rank above the 35/70 distractor pair.
const counts = addArrays(biological, gaussianBinMass(edges, 1500, 35, 1));
const result = detectCellCyclePeakPair(edges, counts);

console.log(JSON.stringify({
  status: result.detection.status,
  confidence: result.detection.confidence,
  selected: result.detection.selectedPair && {
    g1: result.detection.selectedPair.g1.x,
    g2: result.detection.selectedPair.g2.x,
    ratio: result.detection.selectedPair.ratio,
    score: result.detection.selectedPair.score,
    components: result.detection.selectedPair.components,
  },
  alternatives: result.detection.alternatives.map((pair) => ({
    g1: pair.g1.x,
    g2: pair.g2.x,
    ratio: pair.ratio,
    score: pair.score,
  })),
  autoPeakRegions: result.autoPeakRegions,
}, null, 2));
