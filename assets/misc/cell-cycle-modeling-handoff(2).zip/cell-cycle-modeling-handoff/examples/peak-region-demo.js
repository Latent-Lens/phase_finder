import {
  djExpectedCounts,
  fitAutoCellCycle,
} from '../src/index.js';

const edges = Array.from({ length: 257 }, (_, i) => i);
const synthetic = djExpectedCounts(edges, {
  g1Area: 5000,
  g1Mean: 70,
  g1CV: 0.06,
  g2Area: 1800,
  ratio: 2,
  g2CV: 0.06,
  sArea: 3200,
  s0: 0,
  s1: 0.5,
  s2: -0.2,
});

const result = fitAutoCellCycle({
  edges,
  counts: synthetic.total,
  peakRegions: {
    g1: { left: 60, right: 82 },
    g2: { left: 128, right: 152 },
  },
  constraints: {
    ratioMode: 'bounded',
    ratioRange: [1.8, 2.2],
    equalPeakCVs: true,
  },
});

console.log(JSON.stringify({
  selectedModel: result.selection.selected,
  g1Region: result.peakRegions.g1,
  g2Region: result.peakRegions.g2,
  fittedG1Mean: result.selected.params.g1Mean,
  fittedG2Mean: result.selected.params.g2Mean,
  fittedRatio: result.selected.params.ratio,
  migration: result.selected.peakRegionMigration,
  handlesMoved: result.selected.provenance.peakRegionHandlesMovedDuringFit,
  warnings: result.selected.diagnostics.warnings,
}, null, 2));
