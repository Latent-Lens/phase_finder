# Coding-agent implementation brief

## Objective

Implement a browser-based, auditable cell-cycle analysis module that:

1. preprocesses event-level flow-cytometry data;
2. builds a raw one-dimensional DNA histogram;
3. detects G1/G2 candidates across multiple smoothing scales, ranks plausible peak pairs with confidence/alternatives, and displays editable left/right G1 and G2/M peak regions;
4. fits Watson Pragmatic, Dean–Jett (DJ), and Dean–Jett–Fox (DJF) models;
5. optionally fits debris, aggregate, sub-G1-like, and multiple-ploidy components;
6. performs conservative model selection and residual diagnostics;
7. optionally incorporates EdU/BrdU or other phase-associated markers;
8. supports Orlando/CLOCCS analysis for synchronized **time-series** experiments;
9. exports complete provenance and reproducible model settings.

The reference code is dependency-free JavaScript using ES modules. Treat it as a readable implementation scaffold, not a production-validated clinical or diagnostic package.

## Non-negotiable behavior

- Fit the **raw histogram counts**. Multi-scale smoothing is only for display and initialization.
- Preserve automatic-detection status (`detected`, `low_confidence`, or `inferred_g2`), confidence, alternatives, and feature evidence in analysis state and exports.
- User-drawn G1/G2 left/right handles are immutable semantic peak regions—not final phase gates. The fitter may move each fitted center only inside its assigned region and must never silently move the handles or swap G1/G2 identity.
- Compute G1/S/G2 percentages from fitted component areas.
- Report debris, aggregates, and sub-G1-like signal separately from the biological singlet denominator.
- Never call a sub-G1 component “apoptosis” from DNA signal alone.
- Never call a sample “synchronized” merely because DJF beats DJ. Report “complex S-phase model selected.”
- Do not compare Watson against DJ/DJF by ordinary AIC/BIC; Watson’s S phase is a residual decomposition rather than the same kind of generative likelihood.
- Use CLOCCS only when multiple synchronized time points exist. It is not a replacement for a single-histogram fit.

## Recommended architecture

```text
FCS/event input
  -> event QC
  -> histogram builder
  -> hardened multi-scale peak detection and pair scoring
  -> proposed editable peak regions
  -> editable analysis state
  -> model adapter
       -> Watson
       -> DJ
       -> DJF
       -> extended DJ/DJF
       -> CLOCCS time-series
  -> bounded optimizer
  -> diagnostics/model selection
  -> plot components and residuals
  -> phase summaries and export
```

Keep these layers separate:

- **event layer:** rows of measurements and event masks;
- **histogram layer:** edges and integer counts;
- **model layer:** parameters to expected counts;
- **fit layer:** optimizer result and diagnostics;
- **presentation layer:** plot handles, overlays, warnings, and reports.

## Suggested public data contracts

### Histogram

```js
{
  edges: number[],       // length n + 1
  counts: number[],      // length n
  underflow: number,
  overflow: number,
  totalEvents: number,
  dnaChannel: string,
  scale: 'linear'
}
```

### User analysis state

```js
{
  fitDomain: [number, number],
  automaticPeakDetection: {
    status: 'detected' | 'low_confidence' | 'inferred_g2',
    confidence: number,
    selectedPair?: object,
    alternatives: object[],
    reasons: string[]
  },
  peakRegions: {
    g1: { left: number, right: number, boundaryMeaning?: 'peak-window' | 'fwhm' },
    g2: { left: number, right: number, boundaryMeaning?: 'peak-window' | 'fwhm' }
  },
  ratioMode: 'free' | 'bounded' | 'locked',
  ratioRange?: [number, number],
  lockedRatio?: number,
  cvMode: 'free' | 'equal' | 'locked',
  sPhaseModel: 'auto' | 'simple' | 'complex',
  contaminants: {
    debris: 'off' | 'auto' | 'on',
    aggregate: 'off' | 'auto' | 'on',
    subG1: 'off' | 'auto' | 'on'
  },
  ploidyCount: number
}
```

### Fit result

```js
{
  modelName: string,
  converged: boolean,
  params: Record<string, number>,
  bounds: Record<string, [number, number]>,
  expected: number[],
  components: Record<string, number[]>,
  componentAreas: Record<string, number>,
  phaseFractions: { g1: number, s: number, g2: number },
  contaminantFractions: Record<string, number>,
  peakRegionMigration?: {
    g1: { initial: number, fitted: number, absoluteShift: number, shiftAsRegionFraction: number, handlesMoved: false },
    g2: { initial: number, fitted: number, absoluteShift: number, shiftAsRegionFraction: number, handlesMoved: false }
  },
  provenance: {
    peakRegions?: object,
    peakRegionsSource?: 'automatic' | 'user' | 'none',
    peakRegionHandlesMovedDuringFit?: false,
    automaticPeakDetection?: object
  },
  diagnostics: {
    logLikelihood: number,
    poissonDeviance: number,
    reducedPoissonDeviance: number,
    residuals: number[],
    lag1Autocorrelation: number,
    runsTestZ: number,
    boundaryHits: object[],
    peakDetection?: {
      status: string,
      confidence: number,
      peakRegionsSource: string
    },
    warnings: string[]
  }
}
```

## Implementation order

### Milestone 1: single-histogram core

1. Integrate `src/histogram.js`, `src/peakDetection.js`, and `src/initialization.js`.
2. Render the raw histogram plus a clearly labeled primary smoothed display curve; retain all configured smoothing scales for detection provenance.
3. Render automatically proposed G1/G2 regions, status, confidence, and alternative assignments before enabling four draggable peak-region handles: G1-left, G1-right, G2/M-left, and G2/M-right, plus separate read-only fitted-center markers and fit-domain limits.
4. Integrate DJ and DJF expected-count functions.
5. Fit DJ and DJF with `fitHistogramModel()`.
6. Display total fit, components, and deviance residuals.
7. Select simple versus complex S phase with `selectSimpleVsComplex()`.
8. Export parameters, areas, diagnostics, constraints, and user edits.

### Milestone 2: alternative and contaminant models

1. Add Watson Pragmatic as a separately labeled analysis method.
2. Add `extendedCellCycleExpectedCounts()` for optional components.
3. Evaluate optional components one at a time before fitting combinations.
4. Require penalized-fit and residual improvement before retaining an optional component.
5. Add pulse-geometry and viability warnings from event metadata.
6. Add multiple-ploidy mode with ordered means and minimum component areas.

### Milestone 3: multiparameter analysis

1. Accept event-level DNA and EdU/BrdU/marker values.
2. Estimate marker distributions from controls rather than from arbitrary quantiles whenever possible.
3. Compute event-level phase posteriors with `bivariatePhasePosteriors()`.
4. Show a bivariate plot and posterior-derived phase assignments separately from univariate results.
5. Store compensation/transformation metadata and control identifiers.

### Milestone 4: synchronized time-series/CLOCCS

1. Group samples by time after release and biological replicate.
2. Use `cloccsTimeSeriesNll()` as a forward-likelihood scaffold.
3. Add budding-index likelihood when budding measurements exist.
4. Replace the reference optimizer with a validated Bayesian or robust likelihood workflow.
5. Add posterior/parameter uncertainty and convergence diagnostics.

## Automatic component-selection sequence

Use forward selection conservatively:

1. fit the biological base model;
2. inspect regional residual summaries;
3. fit one plausible extra component;
4. refit all active parameters jointly;
5. retain the component only when BIC/AICc and residual structure improve and the component is not at a bound;
6. repeat only if another distinct residual pattern remains;
7. prefer the simpler model when evidence is marginal.

Residual-to-component hints are diagnostic suggestions, not proofs:

| Residual pattern | Candidate action |
|---|---|
| smooth excess below G1 | inspect QC; then consider debris |
| compact peak below G1 | consider sub-G1-like component; require apoptosis marker for biological labeling |
| excess near sums/multiples of singlet DNA | inspect singlet gate; then consider aggregate convolution |
| stable extra G1/G2 pair | consider another ploidy population |
| localized wave between G1 and G2 | compare DJ with DJF |

## Hardened automatic peak detection rules

Implement [`AUTOMATIC_PEAK_DETECTION.md`](AUTOMATIC_PEAK_DETECTION.md) and `src/peakDetection.js` as the front half of the handle workflow.

Required behavior:

- detect candidates at multiple Gaussian smoothing scales;
- merge stable locations across scales and report persistence;
- measure prominence, half-prominence width, approximate local area, and edge truncation;
- estimate intrinsic width after removing smoothing variance so one-bin impulses are downweighted;
- score every plausible ordered pair using the configurable weighted feature model;
- retain ranked alternatives and report heuristic confidence, never a fake calibrated probability;
- propose editable regions using the cleaner G1-left and G2-right shoulders;
- return `low_confidence` for close competing assignments and `inferred_g2` when a partner peak was not actually detected;
- fit with accepted automatic regions by default, but preserve whether regions came from `automatic` or `user` input.

Do not bury ambiguity inside a single pair of coordinates. The UI and export must be able to explain why a pair won and what the closest alternatives were.

## Manual peak-region implementation rules

Use `src/peakRegions.js` rather than treating the handles as ordinary draggable mean anchors.

For regions `G1=[L1,R1]` and `G2=[L2,R2]`:

- reject overlapping or reversed regions;
- initialize each mean from the strongest local peak inside its own region;
- fit `g1Mean` and `g2Mean` directly when the ratio is free or bounded;
- derive `ratio = g2Mean / g1Mean` for the model and report;
- reject trial parameters outside a bounded ratio range;
- for a locked ratio, fit only `g1Mean` over the intersection compatible with both regions and derive `g2Mean`;
- allow Gaussian tails outside the regions;
- preserve the original four handle values exactly in exported provenance;
- report initial-to-final center movement separately from handle positions.

Do not use independent `g1Mean` and `ratio` box bounds when manual G2/M regions are active; that parameterization cannot guarantee the derived G2/M center remains inside the selected G2/M region.

## Parameterization rules

Prefer parameterizations that enforce validity rather than repeatedly clipping invalid values:

- areas: `area = exp(rawArea)` or bounded positive parameter;
- standard deviations/CVs: `sd = exp(rawSd)`;
- unit-interval locations: logistic transformation;
- ordered means: cumulative positive increments;
- mixture weights: softmax;
- G2 mean: `g2Mean = ratio * g1Mean` when ratio-constrained.

The supplied bounded Nelder–Mead implementation uses projection because it is easy to inspect. Replace it in production with a well-tested optimizer and preserve deterministic seeds/configuration.

## Required plots

1. raw counts and optional display smoothing;
2. total expected counts;
3. G1, S, and G2/M expected components;
4. optional contaminants in visually distinct overlays;
5. Pearson or Poisson deviance residuals on a zero-centered panel;
6. immutable user peak regions, separate fitted-center markers, and constraint ranges;
7. clear badges for selected model, convergence, and warnings.

Do not show post-fit classification gates as though they created the model. They are derived from fitted component intersections/posteriors.

## Acceptance criteria

### Numerical

- All expected bin counts are finite and nonnegative.
- Component-area error is below 0.1% on a grid covering essentially all component mass.
- Identical input and configuration produce identical results.
- Synthetic DJ data selects DJ over DJF in most bootstrap replicates at the configured threshold.
- Synthetic DJF data with a substantial interior wave selects DJF and recovers phase fractions within predefined tolerances.
- Failed convergence, boundary parameters, `low_confidence`, and `inferred_g2` initialization are never silently accepted.
- A strong one-bin impulse does not outrank a broader persistent biological peak solely because of height.
- Competing near-doubling pairs are exported and surfaced as ambiguity rather than hidden.

### Biological/reporting

- G1/S/G2 fractions use only fitted biological singlet components.
- Contaminant fractions have a separate denominator and label.
- Missing pulse geometry produces an aggregate warning.
- Sub-G1 is not labeled apoptosis without orthogonal evidence.
- A complex S phase is not labeled synchronized without experiment metadata.

### UI

- Moving a peak-region handle does not immediately change percentages until refitting.
- The optimizer never moves the four user handles; only fitted center markers move inside the regions.
- A fitted center at a region edge produces a visible warning and never silently expands the region.
- G1/G2 identity cannot swap after the user labels the regions.
- Users can reset to the complete automatic detection result, including its original proposed regions.
- Low-confidence assignments visibly expose alternative G1/G2 pairs; inferred G2/M regions are visually distinct.
- Every manual change is included in exported provenance.
- The raw histogram remains visible when smoothing is enabled.
- Residuals are displayed by default, not hidden behind an advanced menu.

### Validation

- Compare against published/synthetic examples and at least one established implementation using identical preprocessing assumptions.
- Validate percentage recovery separately from visual overlay quality.
- Test low counts, one visible peak, late-S dominance, high debris, unresolved doublets, and overlapping ploidies.
- Record versions and tolerances; do not claim exact equivalence to FlowJo or other proprietary implementations.

## Known limitations of this bundle

- The Watson code follows the published/officially documented pragmatic sequence but is not claimed to reproduce any proprietary implementation bit-for-bit.
- The CLOCCS code is a forward-model scaffold, not the complete Bayesian implementation from Orlando et al.
- Optional contaminant forms are useful phenomenological models, not universally correct physical descriptions.
- A single DNA histogram may be non-identifiable: several parameter sets can create nearly indistinguishable curves.
- Multiple ploidies and G1-doublet/G2 overlap may require pulse geometry or orthogonal markers for reliable separation.

## Files to use

- `UI_WORKFLOW.md`: intended user experience and analysis sequence.
- `PEAK_REGION_HANDLES.md`: exact semantics, mathematics, UI behavior, failure handling, and acceptance tests for left/right peak regions.
- `src/peakRegions.js`: validation, region-based initialization, constrained mean parameterization, warnings, and provenance.
- `MODEL_REFERENCE.md`: equations, assumptions, and code entry points.
- `src/models/*.js`: biological expected-count functions.
- `src/optimizer.js`: bounded reference fitting.
- `src/diagnostics.js`: residuals and warnings.
- `src/modelSelection.js`: information criteria and conservative selection.
- `src/multiparameter.js`: event-level marker integration.
- `test/models.test.js`: executable baseline checks.
- `REFERENCES.md` and `references.bib`: citations.
