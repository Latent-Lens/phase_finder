import test from 'node:test';
import assert from 'node:assert/strict';
import {
  aggregateDoubletComponent,
  bivariatePhasePosteriors,
  cloccsExpectedHistogramAtTime,
  djExpectedCounts,
  djfExpectedCounts,
  gaussianBinMass,
  initializeCellCycle,
  detectCellCyclePeakPair,
  applyPeakRegionsToInitialization,
  buildPeakMeanParameterization,
  fitAutoCellCycle,
  fitWatsonPragmatic,
  validatePeakRegions,
  sum,
} from '../src/index.js';

const edges = Array.from({ length: 257 }, (_, i) => i);

const baseParams = {
  g1Area: 5000,
  g1Mean: 70,
  g1CV: 0.06,
  g2Area: 1800,
  ratio: 2,
  g2CV: 0.06,
  sArea: 3200,
  s0: 0,
  s1: 0.5,
  s2: -0.2,
};

test('Gaussian bin mass preserves area on a wide grid', () => {
  const values = gaussianBinMass(edges, 1000, 100, 5);
  assert.ok(Math.abs(sum(values) - 1000) < 1e-3);
});

test('Dean-Jett model returns nonnegative component counts and intended area', () => {
  const model = djExpectedCounts(edges, baseParams);
  assert.equal(model.total.length, edges.length - 1);
  assert.ok(model.total.every((value) => value >= 0));
  assert.ok(Math.abs(sum(model.components.g1) - baseParams.g1Area) < 1);
  assert.ok(Math.abs(sum(model.components.s) - baseParams.sArea) < 1);
  assert.ok(Math.abs(sum(model.components.g2) - baseParams.g2Area) < 1);
});

test('DJF floating wave changes the S-phase shape', () => {
  const simple = djExpectedCounts(edges, baseParams);
  const complex = djfExpectedCounts(edges, {
    ...baseParams,
    waveAmplitude: 5,
    waveMean: 0.65,
    waveSD: 0.08,
  });
  const difference = simple.components.s.reduce((acc, value, i) => acc + Math.abs(value - complex.components.s[i]), 0);
  assert.ok(difference > 100);
});

test('Aggregate self-convolution preserves requested area', () => {
  const model = djExpectedCounts(edges, baseParams);
  const aggregate = aggregateDoubletComponent(edges, model.total, 500);
  assert.ok(Math.abs(sum(aggregate) - 500) < 1e-6);
});

test('Automatic initialization finds a near-doubling peak pair', () => {
  const model = djExpectedCounts(edges, baseParams);
  const init = initializeCellCycle(edges, model.total);
  assert.ok(init.params.ratio > 1.8 && init.params.ratio < 2.2);
});

test('CLOCCS numerical histogram is normalized to event count', () => {
  const result = cloccsExpectedHistogramAtTime(
    edges,
    90,
    { mu0: 15, sigma0: 5, sigmaV: 0.05, lambda: 80, delta: 20, maxCycles: 4 },
    { alpha1: 70, alpha2: 70, tau: 4, gamma1: 0.25, gamma2: 0.55, totalEvents: 10000 },
    { quadraturePoints: 48 },
  );
  assert.ok(Math.abs(sum(result.total) - 10000) < 1e-6);
});

test('Replication marker shifts S-phase posterior upward', () => {
  const model = djExpectedCounts(edges, baseParams);
  const dnaValues = [70, 105, 140];
  const markerValues = [0, 5, 0];
  const posteriors = bivariatePhasePosteriors({
    dnaValues,
    markerValues,
    edges,
    dnaComponents: model.components,
    markerModels: {
      g1: { mean: 0, sd: 1 },
      s: { mean: 5, sd: 1 },
      g2: { mean: 0, sd: 1 },
    },
  });
  assert.equal(posteriors[1].phase, 's');
});

test('Extended model preserves optional component areas', async () => {
  const { extendedCellCycleExpectedCounts } = await import('../src/index.js');
  const extended = extendedCellCycleExpectedCounts(edges, {
    ...baseParams,
    debrisArea: 250,
    debrisRate: 0.05,
    aggregateArea: 400,
  }, {
    enabled: { debris: true, aggregate: true },
    debrisCutoff: 55,
  });
  assert.ok(Math.abs(sum(extended.components.debris) - 250) < 1e-6);
  assert.ok(Math.abs(sum(extended.components.aggregate) - 400) < 1e-6);
});


test('Peak regions preserve semantic G1/G2 identity and initialize inside each region', () => {
  const model = djExpectedCounts(edges, baseParams);
  const automatic = initializeCellCycle(edges, model.total);
  const peakRegions = {
    g1: { left: 60, right: 82 },
    g2: { left: 128, right: 152 },
  };
  const initialized = applyPeakRegionsToInitialization(
    automatic,
    edges,
    model.total,
    peakRegions,
  );
  assert.deepEqual(initialized.anchors.g1Range, [60, 82]);
  assert.deepEqual(initialized.anchors.g2Range, [128, 152]);
  assert.ok(initialized.params.g1Mean >= 60 && initialized.params.g1Mean <= 82);
  assert.ok(initialized.params.g2Mean >= 128 && initialized.params.g2Mean <= 152);
  assert.ok(initialized.params.g1Mean < initialized.params.g2Mean);
});

test('Overlapping semantic peak regions are rejected', () => {
  assert.throws(() => validatePeakRegions({
    g1: { left: 60, right: 90 },
    g2: { left: 85, right: 150 },
  }), /ordered and non-overlapping/);
});

test('Locked ratio is converted into a feasible G1 interval without moving handles', () => {
  const configuration = buildPeakMeanParameterization({
    initial: { ...baseParams, g2Mean: 140 },
    peakRegions: {
      g1: { left: 65, right: 75 },
      g2: { left: 132, right: 148 },
    },
    ratioMode: 'locked',
    lockedRatio: 2,
  });
  assert.deepEqual(configuration.meanKeys, ['g1Mean']);
  assert.deepEqual(configuration.meanBounds.g1Mean, [66, 74]);
  const transformed = configuration.parameterTransform({ ...configuration.initial, g1Mean: 72 });
  assert.equal(transformed.g2Mean, 144);
  assert.equal(transformed.ratio, 2);
});

test('Auto fit keeps fitted centers inside immutable user peak regions', () => {
  const model = djExpectedCounts(edges, baseParams);
  const peakRegions = {
    g1: { left: 62, right: 80 },
    g2: { left: 130, right: 150 },
  };
  const result = fitAutoCellCycle({
    edges,
    counts: model.total,
    peakRegions,
    constraints: { ratioMode: 'bounded', ratioRange: [1.8, 2.2] },
    optimizerOptions: { maxIterations: 250 },
  });
  for (const fit of [result.simple, result.complex]) {
    assert.ok(fit.params.g1Mean >= peakRegions.g1.left && fit.params.g1Mean <= peakRegions.g1.right);
    assert.ok(fit.params.g2Mean >= peakRegions.g2.left && fit.params.g2Mean <= peakRegions.g2.right);
    assert.equal(fit.provenance.peakRegionHandlesMovedDuringFit, false);
    assert.equal(fit.peakRegionMigration.g1.handlesMoved, false);
    assert.equal(fit.peakRegionMigration.g2.handlesMoved, false);
  }
});


test('Watson fitting honors immutable semantic peak regions', () => {
  const model = djExpectedCounts(edges, baseParams);
  const peakRegions = {
    g1: { left: 62, right: 80 },
    g2: { left: 130, right: 150 },
  };
  const fit = fitWatsonPragmatic({ edges, counts: model.total, peakRegions });
  assert.ok(fit.params.g1Mean >= peakRegions.g1.left && fit.params.g1Mean <= peakRegions.g1.right);
  assert.ok(fit.params.g2Mean >= peakRegions.g2.left && fit.params.g2Mean <= peakRegions.g2.right);
  assert.equal(fit.provenance.peakRegionHandlesMovedDuringFit, false);
});


test('Hardened detector reports multi-scale evidence and automatic editable regions', () => {
  const model = djExpectedCounts(edges, baseParams);
  const result = detectCellCyclePeakPair(edges, model.total);
  assert.equal(result.detection.status, 'detected');
  assert.ok(result.detection.confidence >= 0.65);
  assert.ok(Number.isFinite(result.primaryScale));
  assert.ok(result.scaleResults.length >= 3);
  assert.ok(result.detection.g1Candidate.scaleHits.length >= 2);
  assert.ok(result.detection.g2Candidate.scaleHits.length >= 2);
  assert.ok(result.autoPeakRegions.g1.left < baseParams.g1Mean);
  assert.ok(result.autoPeakRegions.g1.right > baseParams.g1Mean);
  assert.ok(result.autoPeakRegions.g2.left < baseParams.g1Mean * baseParams.ratio);
  assert.ok(result.autoPeakRegions.g2.right > baseParams.g1Mean * baseParams.ratio);
  assert.ok(result.autoPeakRegions.g1.right <= result.autoPeakRegions.g2.left);
});

test('Pair scoring rejects a strong sub-G1 distractor when the true pair has a continuous S bridge', () => {
  const biological = djExpectedCounts(edges, baseParams).total;
  const distractor = gaussianBinMass(edges, 1500, 35, 1);
  const counts = biological.map((value, i) => value + distractor[i]);
  const result = detectCellCyclePeakPair(edges, counts);
  assert.ok(Math.abs(result.detection.g1Candidate.x - 70) < 3);
  assert.ok(Math.abs(result.detection.g2Candidate.x - 140) < 5);
  assert.ok(result.detection.selectedPair.components.bridge > 0.9);
});

test('Multi-scale intrinsic-width check downweights one-bin impulse artifacts', () => {
  const counts = gaussianBinMass(edges, 7000, 70, 4);
  counts[100] += 8000;
  const result = detectCellCyclePeakPair(edges, counts);
  const realPeak = result.candidates.find((peak) => Math.abs(peak.x - 70) < 3);
  const impulse = result.candidates.find((peak) => Math.abs(peak.x - 100) < 3);
  assert.ok(realPeak);
  assert.ok(impulse);
  assert.ok(realPeak.intrinsicSigmaBins > 2);
  assert.ok(impulse.intrinsicSigmaBins < 0.75);
  assert.ok(realPeak.quality > impulse.quality);
  assert.equal(result.detection.status, 'inferred_g2');
  assert.ok(Math.abs(result.detection.g1Candidate.x - 70) < 3);
});

test('Competing near-doubling pairs are surfaced as low confidence instead of hidden', () => {
  const counts = [
    gaussianBinMass(edges, 3000, 35, 2),
    gaussianBinMass(edges, 3000, 70, 4),
    gaussianBinMass(edges, 3000, 140, 8),
  ].reduce((acc, component) => acc.map((value, i) => value + component[i]), new Array(edges.length - 1).fill(0));
  const result = detectCellCyclePeakPair(edges, counts);
  assert.equal(result.detection.status, 'low_confidence');
  assert.ok(result.pairs.length >= 2);
  assert.ok(result.detection.alternatives.length >= 1);
  assert.ok(result.detection.confidence < 0.65);
});

test('Auto fitting accepts hardened automatic regions as immutable constraints by default', () => {
  const model = djExpectedCounts(edges, baseParams);
  const result = fitAutoCellCycle({
    edges,
    counts: model.total,
    constraints: { ratioMode: 'bounded', ratioRange: [1.8, 2.2] },
    optimizerOptions: { maxIterations: 250 },
  });
  assert.equal(result.peakRegionsSource, 'automatic');
  assert.ok(result.peakRegions);
  assert.ok(result.selected.params.g1Mean >= result.peakRegions.g1.left);
  assert.ok(result.selected.params.g1Mean <= result.peakRegions.g1.right);
  assert.ok(result.selected.params.g2Mean >= result.peakRegions.g2.left);
  assert.ok(result.selected.params.g2Mean <= result.peakRegions.g2.right);
  assert.equal(result.selected.provenance.peakRegionHandlesMovedDuringFit, false);
  assert.equal(result.selected.provenance.peakRegionsSource, 'automatic');
  assert.equal(result.selected.provenance.automaticPeakDetection.status, 'detected');
});
